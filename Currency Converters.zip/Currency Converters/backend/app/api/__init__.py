from app.api.routes_ocr import router as ocr_router
from app.api.routes_currency import router as currency_router
from app.api.routes_ppp import router as ppp_router
from app.api.routes_budget import router as budget_router
from app.api.routes_product import router as product_router
from app.api.routes_analysis import router as analysis_router

__all__ = [
    "ocr_router",
    "currency_router",
    "ppp_router",
    "budget_router",
    "product_router",
    "analysis_router",
]
