import json
from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.orm import Session
from app.database.connection import get_db
from app.models.analysis import Analysis, OCRResult
from app.models.budget import Budget
from app.models.product import Product
from app.schemas.analysis import (
    AffordabilityCalculateRequest,
    AffordabilityResult,
    CompleteAnalysisRequest,
    AnalysisResponse,
    HistorySummaryItem,
)
from app.services.currency_service import CurrencyService
from app.services.ppp_service import PPPService
from app.services.product_service import ProductService
from app.services.affordability_service import AffordabilityService
from app.services.recommendation_service import RecommendationService
from app.utils.calculations import calculate_disposable_budget

router = APIRouter(prefix="", tags=["Affordability & Complete Analysis"])

@router.post("/affordability/calculate", response_model=AffordabilityResult)
def calculate_affordability_standalone(payload: AffordabilityCalculateRequest):
    """
    Calculate affordability score, budget impact, and recommendation for given numbers.
    """
    res = AffordabilityService.calculate_affordability(
        effective_value=payload.effective_value,
        disposable_budget=payload.disposable_budget,
        monthly_income=payload.monthly_income,
        safe_percentage=payload.safe_budget_percentage or 20.0
    )

    rec_text = RecommendationService.generate_recommendation(
        product_name="Selected Product",
        category="General",
        budget_impact=res["budget_impact"],
        score=res["score"],
        status=res["status"],
        decision=res["decision"],
        effective_value=payload.effective_value,
        safe_budget_price=res["safe_budget_price"]
    )

    return AffordabilityResult(
        budget_impact=res["budget_impact"],
        score=res["score"],
        status=res["status"],
        decision=res["decision"],
        safe_budget_price=res["safe_budget_price"],
        price_difference_safe=res["price_difference_safe"],
        recommendation=rec_text,
        remaining_disposable_budget=res["remaining_disposable_budget"],
        breakdown_steps=res["breakdown_steps"]
    )

@router.post("/analysis", response_model=AnalysisResponse, status_code=status.HTTP_201_CREATED)
async def perform_complete_analysis(
    payload: CompleteAnalysisRequest,
    db: Session = Depends(get_db)
):
    """
    Complete end-to-end purchasing power and affordability decision analysis pipeline.
    """
    # 1. Product Context & Subcategory
    subcategory = payload.subcategory or ProductService.identify_subcategory(payload.category, payload.product_name)
    product = ProductService.get_or_create_product(
        db=db,
        name=payload.product_name,
        category=payload.category,
        subcategory=subcategory,
        image_path=payload.image_path
    )

    # 2. Real-time Exchange Rate
    orig_curr = payload.original_currency.upper()
    target_curr = (payload.target_currency or "INR").upper()
    rate_info = await CurrencyService.get_exchange_rate(orig_curr, target_curr, db=db)
    exchange_rate = rate_info["rate"]
    converted_price = CurrencyService.convert_amount(payload.original_price, exchange_rate)

    # 3. Category-Aware Purchasing Power Parity (PPP)
    country = payload.country or "India"
    ppp_data = PPPService.get_ppp_factor(db, country=country, category=payload.category, currency=target_curr)
    ppp_factor = ppp_data["ppp_factor"]
    effective_value = PPPService.calculate_effective_value(converted_price, ppp_factor)

    # 4. User Monthly Budget Resolution
    user_id = payload.user_id or 1
    if payload.disposable_budget is not None and payload.disposable_budget > 0:
        disposable_budget = payload.disposable_budget
        monthly_income = payload.monthly_income or (disposable_budget * 2.5)
    else:
        # Load user budget from DB
        user_budget = db.query(Budget).filter(Budget.user_id == user_id).first()
        if user_budget:
            monthly_income = user_budget.monthly_income
            disposable_budget = user_budget.disposable_budget
        else:
            monthly_income = 40000.0
            disposable_budget = 10000.0

    # 5. Affordability and Budget Impact Calculations
    affordability = AffordabilityService.calculate_affordability(
        effective_value=effective_value,
        disposable_budget=disposable_budget,
        monthly_income=monthly_income,
        safe_percentage=20.0
    )

    # 6. Contextual Decision & Recommendation Generation
    recommendation_text = RecommendationService.generate_recommendation(
        product_name=payload.product_name,
        category=payload.category,
        budget_impact=affordability["budget_impact"],
        score=affordability["score"],
        status=affordability["status"],
        decision=affordability["decision"],
        effective_value=effective_value,
        safe_budget_price=affordability["safe_budget_price"]
    )

    # Package calculation breakdown for transparency
    breakdown_data = {
        "original_price": f"{payload.original_price:,.2f} {orig_curr}",
        "exchange_rate": f"1 {orig_curr} = {exchange_rate:.4f} {target_curr}",
        "converted_price": f"{converted_price:,.2f} {target_curr}",
        "rate_source": rate_info["source"],
        "rate_timestamp": rate_info["timestamp"].isoformat(),
        "is_rate_cached": rate_info["is_cached"],
        "ppp_factor": ppp_factor,
        "ppp_source": ppp_data["source"],
        "effective_value": f"{effective_value:,.2f} {target_curr}",
        "monthly_income": f"{monthly_income:,.2f} {target_curr}",
        "disposable_budget": f"{disposable_budget:,.2f} {target_curr}",
        "budget_impact": f"{affordability['budget_impact']:.1f}%",
        "affordability_score": affordability["score"],
        "status": affordability["status"],
        "decision": affordability["decision"],
        "safe_budget_price": f"{affordability['safe_budget_price']:,.2f} {target_curr}",
        "price_difference_safe": f"{affordability['price_difference_safe']:,.2f} {target_curr}",
        "remaining_disposable_budget": f"{affordability['remaining_disposable_budget']:,.2f} {target_curr}",
        "breakdown_steps": affordability["breakdown_steps"]
    }

    # 7. Persist Analysis to Database
    analysis_record = Analysis(
        user_id=user_id,
        product_id=product.id,
        product_name=payload.product_name,
        category=payload.category,
        subcategory=subcategory,
        image_path=payload.image_path,
        original_price=payload.original_price,
        original_currency=orig_curr,
        target_currency=target_curr,
        exchange_rate=exchange_rate,
        converted_price=converted_price,
        rate_source=rate_info["source"],
        rate_timestamp=rate_info["timestamp"],
        is_rate_cached=rate_info["is_cached"],
        ppp_factor=ppp_factor,
        effective_value=effective_value,
        country=country,
        monthly_income=monthly_income,
        disposable_budget=disposable_budget,
        budget_impact=affordability["budget_impact"],
        affordability_score=affordability["score"],
        affordability_status=affordability["status"],
        decision=affordability["decision"],
        safe_budget_price=affordability["safe_budget_price"],
        price_difference_safe=affordability["price_difference_safe"],
        recommendation=recommendation_text,
        calculation_breakdown=json.dumps(breakdown_data),
        created_at=datetime.utcnow()
    )
    db.add(analysis_record)
    db.commit()
    db.refresh(analysis_record)

    # 8. Save OCR record if OCR metadata provided
    if payload.raw_ocr_text:
        ocr_rec = OCRResult(
            analysis_id=analysis_record.id,
            raw_text=payload.raw_ocr_text,
            detected_price=payload.original_price,
            detected_currency=orig_curr,
            confidence=payload.ocr_confidence or 0.85,
            created_at=datetime.utcnow()
        )
        db.add(ocr_rec)
        db.commit()

    return AnalysisResponse(
        id=analysis_record.id,
        product_name=analysis_record.product_name,
        category=analysis_record.category,
        subcategory=analysis_record.subcategory,
        image_path=analysis_record.image_path,
        original_price=analysis_record.original_price,
        original_currency=analysis_record.original_currency,
        target_currency=analysis_record.target_currency,
        exchange_rate=analysis_record.exchange_rate,
        converted_price=analysis_record.converted_price,
        rate_source=analysis_record.rate_source,
        rate_timestamp=analysis_record.rate_timestamp,
        is_rate_cached=analysis_record.is_rate_cached,
        country=analysis_record.country,
        ppp_factor=analysis_record.ppp_factor,
        effective_value=analysis_record.effective_value,
        monthly_income=analysis_record.monthly_income,
        disposable_budget=analysis_record.disposable_budget,
        budget_impact=analysis_record.budget_impact,
        affordability_score=analysis_record.affordability_score,
        affordability_status=analysis_record.affordability_status,
        decision=analysis_record.decision,
        safe_budget_price=analysis_record.safe_budget_price,
        price_difference_safe=analysis_record.price_difference_safe,
        remaining_disposable_budget=affordability["remaining_disposable_budget"],
        recommendation=analysis_record.recommendation,
        calculation_breakdown=breakdown_data,
        created_at=analysis_record.created_at
    )

@router.get("/analysis/history", response_model=List[HistorySummaryItem])
def get_analysis_history(
    user_id: int = 1,
    category: Optional[str] = None,
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """
    Retrieve historical product evaluations for user.
    """
    query = db.query(Analysis).filter(Analysis.user_id == user_id)
    if category:
        query = query.filter(Analysis.category.ilike(category))
    
    records = query.order_by(Analysis.created_at.desc()).limit(limit).all()
    return records

@router.get("/analysis/{analysis_id}", response_model=AnalysisResponse)
def get_analysis_by_id(analysis_id: int, db: Session = Depends(get_db)):
    """
    Retrieve single analysis by ID with full calculation breakdown.
    """
    record = db.query(Analysis).filter(Analysis.id == analysis_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    breakdown = {}
    if record.calculation_breakdown:
        try:
            breakdown = json.loads(record.calculation_breakdown)
        except Exception:
            pass

    remaining = round(max(0.0, record.disposable_budget - record.effective_value), 2)

    return AnalysisResponse(
        id=record.id,
        product_name=record.product_name,
        category=record.category,
        subcategory=record.subcategory,
        image_path=record.image_path,
        original_price=record.original_price,
        original_currency=record.original_currency,
        target_currency=record.target_currency,
        exchange_rate=record.exchange_rate,
        converted_price=record.converted_price,
        rate_source=record.rate_source,
        rate_timestamp=record.rate_timestamp,
        is_rate_cached=record.is_rate_cached,
        country=record.country or "India",
        ppp_factor=record.ppp_factor,
        effective_value=record.effective_value,
        monthly_income=record.monthly_income,
        disposable_budget=record.disposable_budget,
        budget_impact=record.budget_impact,
        affordability_score=record.affordability_score,
        affordability_status=record.affordability_status,
        decision=record.decision,
        safe_budget_price=record.safe_budget_price,
        price_difference_safe=record.price_difference_safe,
        remaining_disposable_budget=remaining,
        recommendation=record.recommendation,
        calculation_breakdown=breakdown,
        created_at=record.created_at
    )

@router.delete("/analysis/{analysis_id}")
def delete_analysis_record(analysis_id: int, db: Session = Depends(get_db)):
    """
    Delete an analysis from history.
    """
    record = db.query(Analysis).filter(Analysis.id == analysis_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")

    db.delete(record)
    db.commit()
    return {"message": "Analysis deleted successfully", "id": analysis_id}
