from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.connection import get_db
from app.models.budget import Budget
from app.models.user import User
from app.schemas.budget import BudgetCreate, BudgetUpdate, BudgetResponse, BudgetCalculationResult
from app.utils.calculations import calculate_disposable_budget

router = APIRouter(prefix="/budget", tags=["Personal Budget Profile"])

@router.get("", response_model=BudgetResponse)
def get_user_budget(user_id: int = 1, db: Session = Depends(get_db)):
    """
    Retrieve user's active monthly budget profile.
    """
    budget = db.query(Budget).filter(Budget.user_id == user_id).first()
    if not budget:
        # Create default budget profile
        disposable = calculate_disposable_budget(40000.0, 18000.0, 7000.0, 5000.0)
        budget = Budget(
            user_id=user_id,
            monthly_income=40000.0,
            fixed_expenses=18000.0,
            variable_expenses=7000.0,
            commitments=5000.0,
            disposable_budget=disposable,
            currency="INR"
        )
        db.add(budget)
        db.commit()
        db.refresh(budget)
    return budget

@router.post("", response_model=BudgetResponse)
def save_user_budget(payload: BudgetCreate, db: Session = Depends(get_db)):
    """
    Create or update user's monthly budget profile.
    """
    disposable = calculate_disposable_budget(
        payload.monthly_income,
        payload.fixed_expenses,
        payload.variable_expenses,
        payload.commitments
    )

    budget = db.query(Budget).filter(Budget.user_id == payload.user_id).first()
    if budget:
        budget.monthly_income = payload.monthly_income
        budget.fixed_expenses = payload.fixed_expenses
        budget.variable_expenses = payload.variable_expenses
        budget.commitments = payload.commitments
        budget.disposable_budget = disposable
        budget.currency = payload.currency.upper()
        budget.updated_at = datetime.utcnow()
    else:
        budget = Budget(
            user_id=payload.user_id,
            monthly_income=payload.monthly_income,
            fixed_expenses=payload.fixed_expenses,
            variable_expenses=payload.variable_expenses,
            commitments=payload.commitments,
            disposable_budget=disposable,
            currency=payload.currency.upper(),
            updated_at=datetime.utcnow()
        )
        db.add(budget)

    db.commit()
    db.refresh(budget)
    return budget

@router.post("/calculate", response_model=BudgetCalculationResult)
def calculate_budget_preview(payload: BudgetCreate):
    """
    Compute disposable budget without saving to database.
    """
    total_expenses = payload.fixed_expenses + payload.variable_expenses + payload.commitments
    disposable = calculate_disposable_budget(
        payload.monthly_income,
        payload.fixed_expenses,
        payload.variable_expenses,
        payload.commitments
    )
    savings_rate = round((payload.commitments / payload.monthly_income) * 100.0, 1) if payload.monthly_income > 0 else 0.0

    return BudgetCalculationResult(
        monthly_income=payload.monthly_income,
        fixed_expenses=payload.fixed_expenses,
        variable_expenses=payload.variable_expenses,
        commitments=payload.commitments,
        total_expenses=total_expenses,
        disposable_budget=disposable,
        savings_rate=savings_rate,
        currency=payload.currency.upper()
    )
