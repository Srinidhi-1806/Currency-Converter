from typing import List, Optional
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from app.database.connection import get_db
from app.models.product import Currency
from app.services.currency_service import CurrencyService
from app.schemas.currency import ExchangeRateResponse, ConversionRequest, ConversionResponse
from app.schemas.product import CurrencyResponse

router = APIRouter(tags=["Currency & Exchange Rates"])

@router.get("/exchange-rate", response_model=ExchangeRateResponse)
async def get_exchange_rate(
    from_curr: str = Query("USD", alias="from", description="Source Currency Code"),
    to_curr: str = Query("INR", alias="to", description="Target Currency Code"),
    db: Session = Depends(get_db)
):
    """
    Get live or cached exchange rate between two currencies.
    """
    rate_info = await CurrencyService.get_exchange_rate(from_curr, to_curr, db=db)
    return ExchangeRateResponse(
        from_currency=rate_info["from_currency"],
        to_currency=rate_info["to_currency"],
        rate=rate_info["rate"],
        source=rate_info["source"],
        timestamp=rate_info["timestamp"],
        is_cached=rate_info["is_cached"],
        warning=rate_info["warning"]
    )

@router.post("/currency/convert", response_model=ConversionResponse)
async def convert_currency(
    payload: ConversionRequest,
    db: Session = Depends(get_db)
):
    """
    Convert an amount from one currency to another using current exchange rates.
    """
    rate_info = await CurrencyService.get_exchange_rate(payload.from_currency, payload.to_currency, db=db)
    converted = CurrencyService.convert_amount(payload.amount, rate_info["rate"])

    return ConversionResponse(
        original_amount=payload.amount,
        from_currency=rate_info["from_currency"],
        converted_amount=converted,
        to_currency=rate_info["to_currency"],
        exchange_rate=rate_info["rate"],
        source=rate_info["source"],
        timestamp=rate_info["timestamp"],
        is_cached=rate_info["is_cached"]
    )

@router.get("/currencies", response_model=List[CurrencyResponse])
def get_all_currencies(db: Session = Depends(get_db)):
    """
    List all supported currencies with symbols and names.
    """
    return db.query(Currency).order_by(Currency.code).all()
