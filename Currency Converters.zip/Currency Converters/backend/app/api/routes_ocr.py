import os
import shutil
import uuid
from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from sqlalchemy.orm import Session
from app.config import settings
from app.database.connection import get_db
from app.services.ocr_service import OCRService
from app.schemas.ocr import OCRResponse, OCRCorrectionRequest
from app.utils.validators import validate_image_file, sanitize_filename

router = APIRouter(prefix="/ocr", tags=["OCR Engine"])

@router.post("/analyze", response_model=OCRResponse)
async def analyze_product_image(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Process uploaded product image through OCR preprocessing, price/currency detection, and categorization hints.
    """
    validate_image_file(file)

    # Generate unique filename to avoid collision
    ext = file.filename.split(".")[-1].lower() if "." in file.filename else "jpg"
    unique_name = f"{uuid.uuid4().hex}_{sanitize_filename(file.filename)}"
    save_path = settings.UPLOAD_DIR / unique_name

    try:
        with open(save_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save uploaded image: {str(e)}")

    # Execute OCR Pipeline
    result = OCRService.process_image(str(save_path), unique_name)
    return result
