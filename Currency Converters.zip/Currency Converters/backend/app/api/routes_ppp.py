from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.orm import Session
from app.database.connection import get_db
from app.models.ppp import PPPIndex
from app.services.ppp_service import PPPService
from app.schemas.ppp import (
    PPPIndexBase,
    PPPIndexCreate,
    PPPIndexUpdate,
    PPPIndexResponse,
)

router = APIRouter(prefix="/ppp", tags=["PPP & Purchasing Power Module"])

@router.get("", response_model=dict)
def get_ppp_factor_query(
    country: str = Query("India", description="Country name"),
    category: str = Query("Electronics", description="Product category"),
    currency: Optional[str] = Query("INR", description="Currency code"),
    db: Session = Depends(get_db)
):
    """
    Retrieve category-aware purchasing power parity factor and metadata.
    """
    return PPPService.get_ppp_factor(db, country=country, category=category, currency=currency)

@router.get("/all", response_model=List[PPPIndexResponse])
def get_all_ppp_indices(db: Session = Depends(get_db)):
    """
    Admin/Configuration endpoint: List all configured PPP indices.
    """
    return db.query(PPPIndex).order_by(PPPIndex.country, PPPIndex.category).all()

@router.post("", response_model=PPPIndexResponse, status_code=status.HTTP_201_CREATED)
def create_ppp_index(payload: PPPIndexCreate, db: Session = Depends(get_db)):
    """
    Add a new PPP factor record.
    """
    existing = db.query(PPPIndex).filter(
        PPPIndex.country.ilike(payload.country.strip()),
        PPPIndex.category.ilike(payload.category.strip())
    ).first()

    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"PPP Index for country '{payload.country}' and category '{payload.category}' already exists. Use PUT to update."
        )

    new_index = PPPIndex(
        country=payload.country.strip(),
        currency=payload.currency.strip().upper(),
        category=payload.category.strip(),
        ppp_factor=payload.ppp_factor,
        reference_country=payload.reference_country or "USA",
        source=payload.source or "Custom Category Configuration",
        source_year=payload.source_year or 2024,
        updated_at=datetime.utcnow()
    )
    db.add(new_index)
    db.commit()
    db.refresh(new_index)
    return new_index

@router.put("/{index_id}", response_model=PPPIndexResponse)
def update_ppp_index(
    index_id: int,
    payload: PPPIndexUpdate,
    db: Session = Depends(get_db)
):
    """
    Update an existing PPP adjustment factor.
    """
    item = db.query(PPPIndex).filter(PPPIndex.id == index_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="PPP Index record not found.")

    item.ppp_factor = payload.ppp_factor
    if payload.source:
        item.source = payload.source
    if payload.source_year:
        item.source_year = payload.source_year
    item.updated_at = datetime.utcnow()

    db.commit()
    db.refresh(item)
    return item

@router.delete("/{index_id}")
def delete_ppp_index(index_id: int, db: Session = Depends(get_db)):
    """
    Delete a PPP index record.
    """
    item = db.query(PPPIndex).filter(PPPIndex.id == index_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="PPP Index record not found.")

    db.delete(item)
    db.commit()
    return {"message": "PPP Index deleted successfully", "id": index_id}
