from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database.connection import get_db
from app.models.product import Category, Product
from app.schemas.product import CategoryResponse, ProductResponse
from app.services.product_service import ProductService

router = APIRouter(prefix="/products", tags=["Products & Categories"])

@router.get("/categories", response_model=List[CategoryResponse])
def get_categories(db: Session = Depends(get_db)):
    """
    Get all supported product categories.
    """
    return db.query(Category).order_by(Category.name).all()

@router.get("/identify")
def identify_product_metadata(
    name: str = Query(..., description="Product Name"),
    category: Optional[str] = Query("Electronics", description="Product Category")
):
    """
    Determine subcategory and context clues for a given product.
    """
    subcategory = ProductService.identify_subcategory(category, name)
    return {
        "name": name,
        "category": category,
        "subcategory": subcategory
    }
