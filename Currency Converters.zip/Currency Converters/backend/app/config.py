import os
from pathlib import Path
from pydantic import BaseSettings

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    BASE_DIR: Path = BASE_DIR
    PROJECT_NAME: str = "Context-Aware Product Value & Personal Affordability Analyzer"
    API_V1_STR: str = "/api"
    
    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "mysql+pymysql://root:password@localhost:3306/affordability_db")
    SQLITE_FALLBACK_URL: str = os.getenv("SQLITE_FALLBACK_URL", f"sqlite:///{BASE_DIR}/affordability.db")
    
    # Currency Exchange
    EXCHANGE_RATE_API_KEY: str = os.getenv("EXCHANGE_RATE_API_KEY", "")
    EXCHANGE_RATE_API_URL: str = os.getenv("EXCHANGE_RATE_API_URL", "https://open.er-api.com/v6/latest")
    
    # OCR
    TESSERACT_CMD: str = os.getenv("TESSERACT_CMD", r"C:\Program Files\Tesseract-OCR\tesseract.exe")
    
    # Uploads
    UPLOAD_DIR: Path = BASE_DIR / "uploads"
    MAX_FILE_SIZE_MB: int = 10
    ALLOWED_IMAGE_EXTENSIONS: set = {"jpg", "jpeg", "png", "webp"}
    
    # Default threshold configs for Affordability
    SAFE_BUDGET_PERCENTAGE: float = 20.0  # 20% safe budget impact
    
    # App Mode
    DEBUG: bool = os.getenv("DEBUG", "True").lower() in ("true", "1", "t")
    
    class Config:
        env_file = (str(BASE_DIR / ".env"), ".env")
        case_sensitive = True

settings = Settings()

# Ensure uploads directory exists
settings.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
