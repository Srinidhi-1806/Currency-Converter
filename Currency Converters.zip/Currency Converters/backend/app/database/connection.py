import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.config import settings, BASE_DIR

logger = logging.getLogger("app.database")

Base = declarative_base()

def get_engine():
    # Try connecting to MySQL if configured
    try:
        engine = create_engine(
            settings.DATABASE_URL,
            pool_pre_ping=True,
            pool_recycle=3600,
            connect_args={"connect_timeout": 3} if "mysql" in settings.DATABASE_URL else {}
        )
        # Test connection
        with engine.connect() as conn:
            logger.info("Successfully connected to MySQL Database.")
        return engine
    except Exception as e:
        sqlite_url = settings.SQLITE_FALLBACK_URL
        if sqlite_url.startswith("sqlite:///./"):
            rel_name = sqlite_url[len("sqlite:///./"):]
            sqlite_path = (settings.BASE_DIR / rel_name).resolve().as_posix()
            sqlite_url = f"sqlite:///{sqlite_path}"
        logger.warning(f"MySQL connection failed ({e}). Falling back to SQLite database at {sqlite_url}")
        engine = create_engine(
            sqlite_url,
            connect_args={"check_same_thread": False}
        )
        return engine

engine = get_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
