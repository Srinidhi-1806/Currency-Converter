import logging
from datetime import datetime
from sqlalchemy.orm import Session
from app.database.connection import Base, engine, SessionLocal
from app.models.user import User
from app.models.budget import Budget
from app.models.product import Category, Currency, ExchangeRate, Product
from app.models.ppp import PPPIndex
from app.models.analysis import Analysis, OCRResult

logger = logging.getLogger("app.database.init")

SEED_CATEGORIES = [
    {"name": "Electronics", "description": "Phones, laptops, audio, accessories, and gadgets", "icon": "headphones"},
    {"name": "Fashion", "description": "Clothing, footwear, apparel, and wearables", "icon": "shirt"},
    {"name": "Food", "description": "Dining, restaurants, takeaway, and specialty food", "icon": "utensils"},
    {"name": "Groceries", "description": "Daily staples, supermarket items, produce, household supplies", "icon": "shopping-cart"},
    {"name": "Beauty", "description": "Skincare, cosmetics, fragrances, personal grooming", "icon": "sparkles"},
    {"name": "Healthcare", "description": "Medicines, wellness, fitness equipment, diagnostics", "icon": "heart-pulse"},
    {"name": "Travel", "description": "Flights, hotels, transportation, tours, vacation bookings", "icon": "plane"},
    {"name": "Household", "description": "Appliances, furniture, kitchenware, home improvement", "icon": "home"},
    {"name": "Education", "description": "Books, courses, tuition, certificates, learning materials", "icon": "book-open"},
    {"name": "Entertainment", "description": "Gaming, subscriptions, events, movies, streaming", "icon": "film"},
    {"name": "Other", "description": "General consumer goods and miscellaneous purchases", "icon": "package"},
]

SEED_CURRENCIES = [
    {"code": "INR", "name": "Indian Rupee", "symbol": "₹", "country": "India"},
    {"code": "USD", "name": "United States Dollar", "symbol": "$", "country": "United States"},
    {"code": "EUR", "name": "Euro", "symbol": "€", "country": "Eurozone"},
    {"code": "GBP", "name": "British Pound", "symbol": "£", "country": "United Kingdom"},
    {"code": "JPY", "name": "Japanese Yen", "symbol": "¥", "country": "Japan"},
    {"code": "CAD", "name": "Canadian Dollar", "symbol": "C$", "country": "Canada"},
    {"code": "AUD", "name": "Australian Dollar", "symbol": "A$", "country": "Australia"},
    {"code": "AED", "name": "UAE Dirham", "symbol": "د.إ", "country": "United Arab Emirates"},
    {"code": "SGD", "name": "Singapore Dollar", "symbol": "S$", "country": "Singapore"},
]

# PPP Indices for categories & countries (Ref: USA = 1.0)
SEED_PPP = [
    # INDIA (INR)
    {"country": "India", "currency": "INR", "category": "Electronics", "ppp_factor": 0.82, "source": "Project Category Adjustment Model (Import Tariff & Market Elasticity)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Food", "ppp_factor": 0.35, "source": "Project Category Adjustment Model (Local Labor & Agriculture)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Groceries", "ppp_factor": 0.38, "source": "Project Category Adjustment Model (Essential Staples Basket)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Fashion", "ppp_factor": 0.60, "source": "Project Category Adjustment Model (Domestic Textile & Retail)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Beauty", "ppp_factor": 0.70, "source": "Project Category Adjustment Model (Cosmetics & Personal Care)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Healthcare", "ppp_factor": 0.28, "source": "Project Category Adjustment Model (Generic Pharma & Healthcare)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Travel", "ppp_factor": 0.50, "source": "Project Category Adjustment Model (Domestic Transport & Lodging)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Household", "ppp_factor": 0.55, "source": "Project Category Adjustment Model (Home Appliances & Utilities)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Education", "ppp_factor": 0.40, "source": "Project Category Adjustment Model (Academic Materials & Courses)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Entertainment", "ppp_factor": 0.75, "source": "Project Category Adjustment Model (Digital Subscriptions & Media)", "source_year": 2024},
    {"country": "India", "currency": "INR", "category": "Other", "ppp_factor": 0.65, "source": "Project Category Adjustment Model (General Basket)", "source_year": 2024},

    # UNITED KINGDOM (GBP)
    {"country": "United Kingdom", "currency": "GBP", "category": "Electronics", "ppp_factor": 1.05, "source": "Project Category Adjustment Model (UK VAT & Market Pricing)", "source_year": 2024},
    {"country": "United Kingdom", "currency": "GBP", "category": "Food", "ppp_factor": 0.95, "source": "Project Category Adjustment Model (UK Hospitality)", "source_year": 2024},
    {"country": "United Kingdom", "currency": "GBP", "category": "Groceries", "ppp_factor": 0.90, "source": "Project Category Adjustment Model (UK Supermarket Index)", "source_year": 2024},

    # GERMANY / EUROZONE (EUR)
    {"country": "Germany", "currency": "EUR", "category": "Electronics", "ppp_factor": 1.02, "source": "Project Category Adjustment Model (EU Tech Goods)", "source_year": 2024},
    {"country": "Germany", "currency": "EUR", "category": "Food", "ppp_factor": 0.88, "source": "Project Category Adjustment Model (EU Food Services)", "source_year": 2024},

    # JAPAN (JPY)
    {"country": "Japan", "currency": "JPY", "category": "Electronics", "ppp_factor": 0.92, "source": "Project Category Adjustment Model (Domestic Tech Manufacturing)", "source_year": 2024},
    {"country": "Japan", "currency": "JPY", "category": "Food", "ppp_factor": 0.85, "source": "Project Category Adjustment Model (Japan Consumer Price Basket)", "source_year": 2024},

    # USA (USD - Baseline)
    {"country": "United States", "currency": "USD", "category": "Electronics", "ppp_factor": 1.00, "source": "Baseline Reference Index (US Market)", "source_year": 2024},
    {"country": "United States", "currency": "USD", "category": "Food", "ppp_factor": 1.00, "source": "Baseline Reference Index (US Market)", "source_year": 2024},
]

def init_database():
    """Create all tables and seed initial baseline data"""
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        # 1. Seed Categories
        for cat in SEED_CATEGORIES:
            existing = db.query(Category).filter(Category.name == cat["name"]).first()
            if not existing:
                db.add(Category(**cat))
        
        # 2. Seed Currencies
        for cur in SEED_CURRENCIES:
            existing = db.query(Currency).filter(Currency.code == cur["code"]).first()
            if not existing:
                db.add(Currency(**cur))

        # 3. Seed PPP Indices
        for ppp in SEED_PPP:
            existing = db.query(PPPIndex).filter(
                PPPIndex.country == ppp["country"],
                PPPIndex.category == ppp["category"]
            ).first()
            if not existing:
                db.add(PPPIndex(**ppp))

        # 4. Seed Default User & Budget
        default_user = db.query(User).filter(User.id == 1).first()
        if not default_user:
            default_user = User(
                id=1,
                name="Srinidhi B",
                email="user@affordability.local",
                home_currency="INR"
            )
            db.add(default_user)
            db.flush()

        default_budget = db.query(Budget).filter(Budget.user_id == 1).first()
        if not default_budget:
            default_budget = Budget(
                user_id=1,
                monthly_income=40000.0,
                fixed_expenses=18000.0,
                variable_expenses=7000.0,
                commitments=5000.0,
                disposable_budget=10000.0,
                currency="INR"
            )
            db.add(default_budget)

        db.commit()
        logger.info("Database initialized and seed data successfully populated.")
    except Exception as e:
        db.rollback()
        logger.error(f"Error during DB initialization: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    init_database()
