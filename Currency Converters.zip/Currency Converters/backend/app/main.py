import os
import logging
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from app.config import settings
from app.database.init_db import init_database
from app.api.routes_ocr import router as ocr_router
from app.api.routes_currency import router as currency_router
from app.api.routes_ppp import router as ppp_router
from app.api.routes_budget import router as budget_router
from app.api.routes_product import router as product_router
from app.api.routes_analysis import router as analysis_router

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("app.main")

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing database tables and seed records...")
    init_database()
    logger.info("Antigravity Affordability Analyzer started successfully.")
    yield

# FastAPI App
app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Context-Aware Product Value & Personal Affordability Analyzer API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Uploads directory
app.mount("/uploads", StaticFiles(directory=str(settings.UPLOAD_DIR)), name="uploads")

# Frontend directory path
FRONTEND_DIR = Path(__file__).resolve().parent.parent.parent / "frontend"

# Include API Routers under /api
app.include_router(ocr_router, prefix=settings.API_V1_STR)
app.include_router(currency_router, prefix=settings.API_V1_STR)
app.include_router(ppp_router, prefix=settings.API_V1_STR)
app.include_router(budget_router, prefix=settings.API_V1_STR)
app.include_router(product_router, prefix=settings.API_V1_STR)
app.include_router(analysis_router, prefix=settings.API_V1_STR)

@app.get("/health", tags=["Health"])
@app.get("/api/health", tags=["Health"])
def health_check():
    return {
        "status": "healthy",
        "app": settings.PROJECT_NAME,
        "version": "1.0.0"
    }

# Mount Frontend static files if directory exists
if FRONTEND_DIR.exists():
    app.mount("/css", StaticFiles(directory=str(FRONTEND_DIR / "css")), name="css")
    app.mount("/js", StaticFiles(directory=str(FRONTEND_DIR / "js")), name="js")
    if (FRONTEND_DIR / "assets").exists():
        app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIR / "assets")), name="assets")

    @app.get("/", include_in_schema=False)
    @app.get("/index", include_in_schema=False)
    @app.get("/index.html", include_in_schema=False)
    def serve_index():
        return FileResponse(FRONTEND_DIR / "index.html")

    @app.get("/analyze", include_in_schema=False)
    @app.get("/analyze.html", include_in_schema=False)
    def serve_analyze():
        return FileResponse(FRONTEND_DIR / "analyze.html")

    @app.get("/budget", include_in_schema=False)
    @app.get("/budget.html", include_in_schema=False)
    def serve_budget():
        return FileResponse(FRONTEND_DIR / "budget.html")

    @app.get("/result", include_in_schema=False)
    @app.get("/result.html", include_in_schema=False)
    def serve_result():
        return FileResponse(FRONTEND_DIR / "result.html")

    @app.get("/history", include_in_schema=False)
    @app.get("/history.html", include_in_schema=False)
    def serve_history():
        return FileResponse(FRONTEND_DIR / "history.html")

    @app.get("/ppp-manager", include_in_schema=False)
    @app.get("/ppp-manager.html", include_in_schema=False)
    def serve_ppp_manager():
        return FileResponse(FRONTEND_DIR / "ppp-manager.html")

