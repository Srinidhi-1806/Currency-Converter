from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import relationship
from app.database.connection import Base

class Analysis(Base):
    __tablename__ = "analyses"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=True)
    
    product_name = Column(String(150), nullable=False)
    category = Column(String(50), nullable=False)
    subcategory = Column(String(50), nullable=True)
    image_path = Column(String(255), nullable=True)
    
    # Financial Inputs
    original_price = Column(Float, nullable=False)
    original_currency = Column(String(10), nullable=False)
    target_currency = Column(String(10), nullable=False, default="INR")
    
    # Currency conversion
    exchange_rate = Column(Float, nullable=False)
    converted_price = Column(Float, nullable=False)
    rate_source = Column(String(100), default="Real-Time Exchange Rate API")
    rate_timestamp = Column(DateTime, default=datetime.utcnow)
    is_rate_cached = Column(Boolean, default=False)
    
    # PPP adjustment
    ppp_factor = Column(Float, nullable=False, default=1.0)
    effective_value = Column(Float, nullable=False)
    country = Column(String(50), default="India")
    
    # Budget Context
    monthly_income = Column(Float, nullable=False)
    disposable_budget = Column(Float, nullable=False)
    budget_impact = Column(Float, nullable=False) # %
    
    # Affordability & Decisions
    affordability_score = Column(Integer, nullable=False) # 0 - 100
    affordability_status = Column(String(50), nullable=False) # Affordable, High Budget Impact, etc.
    decision = Column(String(20), nullable=False) # BUY, CONSIDER, WAIT, NOT RECOMMENDED
    safe_budget_price = Column(Float, nullable=False)
    price_difference_safe = Column(Float, nullable=False)
    
    recommendation = Column(Text, nullable=False)
    calculation_breakdown = Column(Text, nullable=True) # JSON details
    
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="analyses")
    product = relationship("Product", back_populates="analyses")
    ocr_results = relationship("OCRResult", back_populates="analysis", cascade="all, delete-orphan")

class OCRResult(Base):
    __tablename__ = "ocr_results"

    id = Column(Integer, primary_key=True, index=True)
    analysis_id = Column(Integer, ForeignKey("analyses.id"), nullable=True)
    raw_text = Column(Text, nullable=True)
    detected_price = Column(Float, nullable=True)
    detected_currency = Column(String(10), nullable=True)
    confidence = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)

    analysis = relationship("Analysis", back_populates="ocr_results")
