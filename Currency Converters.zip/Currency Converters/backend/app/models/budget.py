from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database.connection import Base

class Budget(Base):
    __tablename__ = "budgets"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    monthly_income = Column(Float, nullable=False, default=40000.0)
    fixed_expenses = Column(Float, nullable=False, default=18000.0)
    variable_expenses = Column(Float, nullable=False, default=7000.0)
    commitments = Column(Float, nullable=False, default=5000.0)
    disposable_budget = Column(Float, nullable=False, default=10000.0)
    currency = Column(String(10), nullable=False, default="INR")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="budgets")
