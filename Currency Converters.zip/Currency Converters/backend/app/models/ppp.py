from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime
from app.database.connection import Base

class PPPIndex(Base):
    __tablename__ = "ppp_indices"

    id = Column(Integer, primary_key=True, index=True)
    country = Column(String(50), index=True, nullable=False)
    currency = Column(String(10), index=True, nullable=False)
    category = Column(String(50), index=True, nullable=False)
    ppp_factor = Column(Float, nullable=False, default=1.0)
    reference_country = Column(String(50), default="USA")
    source = Column(String(200), default="Analytical PPP / Category Model")
    source_year = Column(Integer, default=2024)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
