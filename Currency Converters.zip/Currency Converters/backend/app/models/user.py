from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.orm import relationship
from app.database.connection import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, default="Default User")
    email = Column(String(150), unique=True, index=True, nullable=True)
    home_currency = Column(String(10), nullable=False, default="INR")
    created_at = Column(DateTime, default=datetime.utcnow)

    budgets = relationship("Budget", back_populates="user", cascade="all, delete-orphan")
    analyses = relationship("Analysis", back_populates="user", cascade="all, delete-orphan")
