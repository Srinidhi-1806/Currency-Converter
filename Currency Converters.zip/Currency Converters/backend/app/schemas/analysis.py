from typing import Optional, Dict, Any, List
from datetime import datetime
from pydantic import BaseModel, Field

class AffordabilityCalculateRequest(BaseModel):
    effective_value: float = Field(..., gt=0)
    disposable_budget: float = Field(..., description="User's monthly disposable budget")
    monthly_income: Optional[float] = None
    safe_budget_percentage: Optional[float] = 20.0

class CalculationStep(BaseModel):
    step_number: int
    title: str
    formula: str
    input_values: Dict[str, Any]
    result: Any
    explanation: str

class AffordabilityResult(BaseModel):
    budget_impact: float
    score: int
    status: str
    decision: str
    safe_budget_price: float
    price_difference_safe: float
    recommendation: str
    remaining_disposable_budget: float
    breakdown_steps: Optional[List[CalculationStep]] = None

class CompleteAnalysisRequest(BaseModel):
    user_id: Optional[int] = 1
    product_name: str
    category: str
    subcategory: Optional[str] = None
    original_price: float = Field(..., gt=0)
    original_currency: str
    target_currency: Optional[str] = "INR"
    country: Optional[str] = "India"
    image_path: Optional[str] = None
    
    # Optional direct budget overrides (or fetched from user profile)
    monthly_income: Optional[float] = None
    fixed_expenses: Optional[float] = None
    variable_expenses: Optional[float] = None
    commitments: Optional[float] = None
    disposable_budget: Optional[float] = None
    
    # OCR metadata if applicable
    raw_ocr_text: Optional[str] = None
    ocr_confidence: Optional[float] = None

class AnalysisResponse(BaseModel):
    id: int
    product_name: str
    category: str
    subcategory: Optional[str] = None
    image_path: Optional[str] = None
    
    # Currencies & Price
    original_price: float
    original_currency: str
    target_currency: str
    exchange_rate: float
    converted_price: float
    rate_source: str
    rate_timestamp: datetime
    is_rate_cached: bool
    
    # PPP
    country: str
    ppp_factor: float
    effective_value: float
    
    # Budget & Affordability
    monthly_income: float
    disposable_budget: float
    budget_impact: float
    affordability_score: int
    affordability_status: str
    decision: str
    safe_budget_price: float
    price_difference_safe: float
    remaining_disposable_budget: float
    
    recommendation: str
    calculation_breakdown: Optional[Dict[str, Any]] = None
    created_at: datetime

    class Config:
        orm_mode = True

class HistorySummaryItem(BaseModel):
    id: int
    product_name: str
    category: str
    original_price: float
    original_currency: str
    target_currency: str
    converted_price: float
    effective_value: float
    disposable_budget: float
    budget_impact: float
    affordability_score: int
    affordability_status: str
    decision: str
    created_at: datetime

    class Config:
        orm_mode = True
