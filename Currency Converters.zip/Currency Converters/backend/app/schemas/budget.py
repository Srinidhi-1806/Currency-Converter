from typing import Optional
from datetime import datetime
from pydantic import BaseModel, Field

class BudgetBase(BaseModel):
    monthly_income: float = Field(..., gt=0, description="Monthly income in home currency")
    fixed_expenses: float = Field(0.0, ge=0, description="Fixed monthly expenses like rent, bills")
    variable_expenses: float = Field(0.0, ge=0, description="Variable expenses like dining, entertainment")
    commitments: float = Field(0.0, ge=0, description="Savings, debt commitments, investments")
    currency: str = Field("INR", max_length=10)

class BudgetCreate(BudgetBase):
    user_id: Optional[int] = 1

class BudgetUpdate(BudgetBase):
    pass

class BudgetResponse(BudgetBase):
    id: int
    user_id: int
    disposable_budget: float
    updated_at: datetime

    class Config:
        orm_mode = True

class BudgetCalculationResult(BaseModel):
    monthly_income: float
    fixed_expenses: float
    variable_expenses: float
    commitments: float
    total_expenses: float
    disposable_budget: float
    savings_rate: float
    currency: str
