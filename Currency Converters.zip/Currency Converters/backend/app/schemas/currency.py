from typing import Optional
from datetime import datetime
from pydantic import BaseModel, Field

class ExchangeRateResponse(BaseModel):
    from_currency: str
    to_currency: str
    rate: float
    source: str
    timestamp: datetime
    is_cached: bool = False
    warning: Optional[str] = None

class ConversionRequest(BaseModel):
    amount: float = Field(..., gt=0)
    from_currency: str
    to_currency: str

class ConversionResponse(BaseModel):
    original_amount: float
    from_currency: str
    converted_amount: float
    to_currency: str
    exchange_rate: float
    source: str
    timestamp: datetime
    is_cached: bool
