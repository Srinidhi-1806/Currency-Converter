from typing import Optional
from pydantic import BaseModel, Field

class OCRResponse(BaseModel):
    raw_text: str
    price: Optional[float] = None
    currency: Optional[str] = None
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    product_name_suggestion: Optional[str] = None
    category_suggestion: Optional[str] = None
    is_low_confidence: bool = False
    warning_message: Optional[str] = None
    image_url: Optional[str] = None

class OCRCorrectionRequest(BaseModel):
    raw_text: Optional[str] = None
    price: float
    currency: str
    product_name: str
    category: str
