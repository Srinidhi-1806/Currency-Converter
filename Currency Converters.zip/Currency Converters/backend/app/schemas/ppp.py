from typing import Optional
from datetime import datetime
from pydantic import BaseModel, Field

class PPPIndexBase(BaseModel):
    country: str
    currency: str
    category: str
    ppp_factor: float = Field(..., gt=0.0, description="Purchasing Power Adjustment Factor")
    reference_country: Optional[str] = "USA"
    source: Optional[str] = "Analytical PPP / Category Model"
    source_year: Optional[int] = 2024

class PPPIndexCreate(PPPIndexBase):
    pass

class PPPIndexUpdate(BaseModel):
    ppp_factor: float = Field(..., gt=0.0)
    source: Optional[str] = None
    source_year: Optional[int] = None

class PPPIndexResponse(PPPIndexBase):
    id: int
    updated_at: datetime

    class Config:
        orm_mode = True

class PPPFactorQuery(BaseModel):
    country: str
    category: str
    currency: Optional[str] = None
