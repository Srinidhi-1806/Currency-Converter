from typing import Optional, List
from pydantic import BaseModel

class CategoryResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    icon: Optional[str] = "tag"

    class Config:
        orm_mode = True

class CurrencyResponse(BaseModel):
    id: int
    code: str
    name: str
    symbol: str
    country: Optional[str] = None

    class Config:
        orm_mode = True

class ProductBase(BaseModel):
    name: str
    category: str
    subcategory: Optional[str] = None
    image_path: Optional[str] = None

class ProductCreate(ProductBase):
    pass

class ProductResponse(ProductBase):
    id: int

    class Config:
        orm_mode = True
