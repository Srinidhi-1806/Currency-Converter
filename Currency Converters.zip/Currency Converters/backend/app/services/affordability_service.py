from typing import Dict, Any, List, Optional
from app.utils.calculations import (
    calculate_disposable_budget,
    calculate_budget_impact,
    calculate_affordability_score,
    classify_affordability,
    calculate_safe_budget_price,
)
from app.config import settings

class AffordabilityService:
    @staticmethod
    def calculate_affordability(
        effective_value: float,
        disposable_budget: float,
        monthly_income: Optional[float] = None,
        safe_percentage: float = 20.0,
        currency_symbol: str = "₹"
    ) -> Dict[str, Any]:
        """
        Compute complete affordability analysis with step-by-step mathematical transparency.
        """
        budget_impact = calculate_budget_impact(effective_value, disposable_budget)
        score = calculate_affordability_score(effective_value, disposable_budget, monthly_income)
        status, decision = classify_affordability(score, budget_impact, disposable_budget)
        safe_budget_price = calculate_safe_budget_price(disposable_budget, safe_percentage)
        price_diff_safe = round(effective_value - safe_budget_price, 2)
        remaining_budget = round(max(0.0, disposable_budget - effective_value), 2)

        # Build transparent calculation breakdown steps
        breakdown_steps = [
            {
                "step_number": 1,
                "title": "Disposable Budget Formulation",
                "formula": "Disposable Budget = Monthly Income - (Fixed + Variable + Commitments)",
                "input_values": {
                    "monthly_income": monthly_income or "Configured Profile",
                    "disposable_budget": disposable_budget
                },
                "result": f"{currency_symbol}{disposable_budget:,.2f}",
                "explanation": "Calculates the actual uncommitted discretionary cash flow available for discretionary purchases."
            },
            {
                "step_number": 2,
                "title": "Purchasing Power Parity (PPP) Adjustment",
                "formula": "Effective Product Value = Converted Price × Category PPP Factor",
                "input_values": {
                    "effective_value": effective_value
                },
                "result": f"{currency_symbol}{effective_value:,.2f}",
                "explanation": "Contextualizes nominal market price against local economic purchasing power and category elasticity."
            },
            {
                "step_number": 3,
                "title": "Personal Budget Impact",
                "formula": "Budget Impact % = (Effective Product Value / Disposable Monthly Budget) × 100",
                "input_values": {
                    "effective_value": effective_value,
                    "disposable_budget": disposable_budget
                },
                "result": f"{budget_impact:.1f}%",
                "explanation": f"The product will consume {budget_impact:.1f}% of your monthly disposable funds."
            },
            {
                "step_number": 4,
                "title": "Deterministic Affordability Score (0-100)",
                "formula": "Score = Piecewise Deterministic Non-Linear Function(Budget Impact %, Disposable Budget Ratio)",
                "input_values": {
                    "budget_impact": f"{budget_impact:.1f}%"
                },
                "result": f"{score} / 100 ({status})",
                "explanation": f"Produces an objective score where higher numbers indicate superior financial safety and low wallet friction."
            },
            {
                "step_number": 5,
                "title": "Budget-Safe Threshold Analysis",
                "formula": f"Safe Budget Value = Disposable Budget × {safe_percentage:.0f}%",
                "input_values": {
                    "safe_percentage": f"{safe_percentage}%",
                    "safe_threshold": safe_budget_price
                },
                "result": f"{currency_symbol}{safe_budget_price:,.2f}",
                "explanation": f"Purchases below {currency_symbol}{safe_budget_price:,.2f} maintain optimal savings buffers."
            }
        ]

        return {
            "budget_impact": budget_impact,
            "score": score,
            "status": status,
            "decision": decision,
            "safe_budget_price": safe_budget_price,
            "price_difference_safe": price_diff_safe,
            "remaining_disposable_budget": remaining_budget,
            "breakdown_steps": breakdown_steps
        }
