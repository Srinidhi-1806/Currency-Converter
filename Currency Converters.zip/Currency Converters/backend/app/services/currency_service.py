import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
import httpx
from sqlalchemy.orm import Session
from app.config import settings
from app.models.product import ExchangeRate

logger = logging.getLogger("app.services.currency")

# Fallback base rates (in case API is unreachable on fresh DB)
FALLBACK_RATES = {
    ("USD", "INR"): 83.50,
    ("USD", "EUR"): 0.92,
    ("USD", "GBP"): 0.79,
    ("USD", "JPY"): 155.20,
    ("USD", "CAD"): 1.36,
    ("USD", "AUD"): 1.52,
    ("USD", "USD"): 1.0,

    ("EUR", "INR"): 90.75,
    ("EUR", "USD"): 1.09,
    ("EUR", "GBP"): 0.86,
    ("EUR", "JPY"): 168.50,
    ("EUR", "EUR"): 1.0,

    ("GBP", "INR"): 105.50,
    ("GBP", "USD"): 1.27,
    ("GBP", "EUR"): 1.16,
    ("GBP", "GBP"): 1.0,

    ("INR", "USD"): 0.012,
    ("INR", "EUR"): 0.011,
    ("INR", "GBP"): 0.0095,
    ("INR", "INR"): 1.0,

    ("JPY", "INR"): 0.54,
    ("JPY", "USD"): 0.0064,
    ("JPY", "JPY"): 1.0,
}

class CurrencyService:
    @staticmethod
    async def get_exchange_rate(
        from_curr: str,
        to_curr: str,
        db: Optional[Session] = None
    ) -> Dict[str, Any]:
        """
        Fetch real-time exchange rate with caching and graceful error fallback.
        """
        from_curr = from_curr.upper()
        to_curr = to_curr.upper()

        if from_curr == to_curr:
            return {
                "from_currency": from_curr,
                "to_currency": to_curr,
                "rate": 1.0,
                "source": "Identity (Same Currency)",
                "timestamp": datetime.utcnow(),
                "is_cached": False,
                "warning": None
            }

        # 1. Check if we have a very recent rate in database (within last 1 hour)
        cached_record = None
        if db:
            cached_record = db.query(ExchangeRate).filter(
                ExchangeRate.base_currency == from_curr,
                ExchangeRate.target_currency == to_curr
            ).order_by(ExchangeRate.timestamp.desc()).first()

            if cached_record and (datetime.utcnow() - cached_record.timestamp < timedelta(hours=1)):
                return {
                    "from_currency": from_curr,
                    "to_currency": to_curr,
                    "rate": cached_record.rate,
                    "source": cached_record.source,
                    "timestamp": cached_record.timestamp,
                    "is_cached": True,
                    "warning": None
                }

        # 2. Attempt fetching from real-time API
        try:
            url = f"{settings.EXCHANGE_RATE_API_URL}/{from_curr}"
            async with httpx.AsyncClient(timeout=4.0) as client:
                response = await client.get(url)
                if response.status_code == 200:
                    data = response.json()
                    rates = data.get("rates", {})
                    if to_curr in rates:
                        rate_val = float(rates[to_curr])
                        source_name = f"Open Exchange Rate API ({data.get('provider', 'open.er-api.com')})"
                        now = datetime.utcnow()

                        # Cache rate to database
                        if db:
                            try:
                                new_rate = ExchangeRate(
                                    base_currency=from_curr,
                                    target_currency=to_curr,
                                    rate=rate_val,
                                    source=source_name,
                                    timestamp=now
                                )
                                db.add(new_rate)
                                db.commit()
                            except Exception as db_err:
                                db.rollback()
                                logger.warning(f"Failed to cache exchange rate in DB: {db_err}")

                        return {
                            "from_currency": from_curr,
                            "to_currency": to_curr,
                            "rate": rate_val,
                            "source": source_name,
                            "timestamp": now,
                            "is_cached": False,
                            "warning": None
                        }
        except Exception as api_err:
            logger.warning(f"Real-time exchange rate API request failed: {api_err}")

        # 3. If API failed, check older cache
        if cached_record:
            return {
                "from_currency": from_curr,
                "to_currency": to_curr,
                "rate": cached_record.rate,
                "source": f"{cached_record.source} (Offline Cache)",
                "timestamp": cached_record.timestamp,
                "is_cached": True,
                "warning": "Live exchange rate API unavailable. Using cached rate."
            }

        # 4. Fallback to standard base table
        fallback_rate = FALLBACK_RATES.get((from_curr, to_curr))
        if fallback_rate is None:
            # Try inverse or default to 1.0
            inverse = FALLBACK_RATES.get((to_curr, from_curr))
            fallback_rate = round(1.0 / inverse, 4) if inverse else 1.0

        return {
            "from_currency": from_curr,
            "to_currency": to_curr,
            "rate": fallback_rate,
            "source": "Standard Reference Rate (Offline Fallback)",
            "timestamp": datetime.utcnow(),
            "is_cached": True,
            "warning": "Live exchange rate service temporarily offline. Using standard reference rate."
        }

    @staticmethod
    def convert_amount(amount: float, rate: float) -> float:
        return round(amount * rate, 2)
