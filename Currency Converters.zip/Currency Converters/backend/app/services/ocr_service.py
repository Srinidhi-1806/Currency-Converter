import re
import os
import logging
from typing import Dict, Any, Optional, Tuple
import cv2
import numpy as np
from PIL import Image
import pytesseract
from app.config import settings

logger = logging.getLogger("app.services.ocr")

# Configure tesseract path if specified and exists
if os.path.exists(settings.TESSERACT_CMD):
    pytesseract.pytesseract.tesseract_cmd = settings.TESSERACT_CMD
elif os.path.exists(r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"):
    pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"

CURRENCY_SYMBOLS_MAP = {
    "$": "USD",
    "₹": "INR",
    "rs": "INR",
    "rs.": "INR",
    "inr": "INR",
    "€": "EUR",
    "eur": "EUR",
    "£": "GBP",
    "gbp": "GBP",
    "¥": "JPY",
    "jpy": "JPY",
    "usd": "USD",
    "c$": "CAD",
    "cad": "CAD",
    "a$": "AUD",
    "aud": "AUD",
}

CATEGORY_KEYWORDS = {
    "Electronics": ["headphone", "headphones", "earbuds", "laptop", "phone", "smartphone", "tv", "camera", "speaker", "tablet", "monitor", "keyboard", "mouse", "charger", "sony", "apple", "samsung", "bose", "anker"],
    "Fashion": ["shirt", "t-shirt", "jeans", "jacket", "shoes", "sneakers", "dress", "hoodie", "pants", "watch", "leather", "handbag", "clothing", "wear"],
    "Food": ["burger", "pizza", "meal", "coffee", "restaurant", "cafe", "sandwich", "lunch", "dinner", "snack"],
    "Groceries": ["milk", "bread", "eggs", "rice", "flour", "oil", "fruits", "vegetables", "cereal", "butter", "cheese", "grocery", "supermarket"],
    "Beauty": ["perfume", "cologne", "lipstick", "cream", "lotion", "serum", "makeup", "shampoo", "skincare", "fragrance"],
    "Healthcare": ["medicine", "vitamins", "supplements", "thermometer", "mask", "bandage", "first aid", "pills"],
    "Travel": ["flight", "hotel", "ticket", "resort", "airbnb", "train", "tour", "booking", "luggage"],
    "Household": ["vacuum", "blender", "microwave", "pillow", "blanket", "chair", "table", "lamp", "cookware", "pan"],
    "Education": ["book", "textbook", "course", "calculator", "stationery", "notebook", "pen"],
    "Entertainment": ["game", "playstation", "xbox", "nintendo", "movie", "concert", "subscription", "ticket", "vinyl"]
}

class OCRService:
    @staticmethod
    def preprocess_image(image_path: str) -> np.ndarray:
        """
        Multi-step image preprocessing pipeline:
        Grayscale -> Noise Reduction (Bilateral / Gaussian) -> Adaptive / Otsu Thresholding
        """
        img = cv2.imread(image_path)
        if img is None:
            # Fallback with PIL in case of Unicode path issues on Windows
            pil_img = Image.open(image_path)
            img = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        # 1. Resize if image is too small to improve OCR accuracy
        height, width = img.shape[:2]
        if width < 800 or height < 800:
            scale = max(800 / width, 800 / height)
            img = cv2.resize(img, (int(width * scale), int(height * scale)), interpolation=cv2.INTER_CUBIC)

        # 2. Grayscale conversion
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # 3. Noise reduction using bilateral filter (preserves edges while removing noise)
        denoised = cv2.bilateralFilter(gray, 9, 75, 75)

        # 4. Contrast enhancement via CLAHE (Contrast Limited Adaptive Histogram Equalization)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(denoised)

        # 5. Otsu's thresholding for high contrast binarization
        _, thresh = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        return thresh

    @staticmethod
    def extract_text(image_path: str) -> Tuple[str, float]:
        """
        Extract text using Tesseract OCR with fallback handling.
        Returns (raw_text, confidence)
        """
        try:
            processed_img = OCRService.preprocess_image(image_path)
            
            # Custom Tesseract configuration for price & text recognition
            custom_config = r'--oem 3 --psm 6'
            
            # Try getting image data with confidences
            data = pytesseract.image_to_data(processed_img, output_type=pytesseract.Output.DICT, config=custom_config)
            
            words = []
            confidences = []
            for i in range(len(data['text'])):
                w = data['text'][i].strip()
                c = float(data['conf'][i])
                if w and c > 0:
                    words.append(w)
                    confidences.append(c)
            
            extracted_text = " ".join(words)
            if not extracted_text.strip():
                # Try simple image_to_string directly on original PIL image
                raw_str = pytesseract.image_to_string(Image.open(image_path), config=custom_config)
                extracted_text = raw_str.strip()
                avg_confidence = 0.6 if extracted_text else 0.0
            else:
                avg_confidence = round(sum(confidences) / (len(confidences) * 100.0), 2) if confidences else 0.5
            
            return extracted_text, avg_confidence

        except Exception as e:
            logger.warning(f"Tesseract OCR not accessible or encountered error: {e}")
            # If tesseract is not installed locally on system PATH, attempt fallback parsing
            return "", 0.0

    @staticmethod
    def parse_price_and_currency(text: str) -> Tuple[Optional[float], Optional[str], float]:
        """
        Detect price and currency from extracted text using comprehensive regex patterns.
        Handles:
        - $49.99, ₹2,499, €29.99, £35, ¥5000, C$59, A$75
        - USD 49.99, INR 2499, EUR 29.99, GBP 35, JPY 5000
        - 49.99 USD, 2499 INR, 29.99 EUR
        - Rs. 2,499 / Rs 2499
        """
        if not text:
            return None, None, 0.0

        confidence = 0.5
        detected_price = None
        detected_currency = None

        # Clean text
        normalized_text = text.replace(",", "")

        # Pattern 1: Symbol before number ($49.99, ₹2499, €29.99, £35, ¥5000, Rs. 2499)
        pattern1 = r'([\$₹€£¥]|Rs\.?|INR|USD|EUR|GBP|JPY|CAD|AUD)\s*([0-9]+(?:\.[0-9]{1,2})?)'
        matches1 = re.findall(pattern1, normalized_text, re.IGNORECASE)

        # Pattern 2: Code after number (49.99 USD, 2499 INR, 29.99 EUR)
        pattern2 = r'([0-9]+(?:\.[0-9]{1,2})?)\s*([\$₹€£¥]|Rs\.?|INR|USD|EUR|GBP|JPY|CAD|AUD)'
        matches2 = re.findall(pattern2, normalized_text, re.IGNORECASE)

        # Pattern 3: Standalone prices with decimal like 49.99 or 2499.00
        pattern3 = r'\b([0-9]+\.[0-9]{2})\b'
        matches3 = re.findall(pattern3, normalized_text)

        if matches1:
            sym, p_str = matches1[0]
            try:
                detected_price = float(p_str)
                detected_currency = CURRENCY_SYMBOLS_MAP.get(sym.lower(), "USD")
                confidence = 0.92
            except ValueError:
                pass

        elif matches2:
            p_str, sym = matches2[0]
            try:
                detected_price = float(p_str)
                detected_currency = CURRENCY_SYMBOLS_MAP.get(sym.lower(), "USD")
                confidence = 0.88
            except ValueError:
                pass

        elif matches3:
            try:
                detected_price = float(matches3[0])
                detected_currency = "USD"  # Default assumption if only number
                confidence = 0.65
            except ValueError:
                pass

        return detected_price, detected_currency, confidence

    @staticmethod
    def infer_product_details(text: str) -> Tuple[str, str]:
        """
        Infer suggested product name and category from OCR text.
        """
        if not text:
            return "Sample Product", "Electronics"

        text_lower = text.lower()
        detected_category = "Electronics"

        # Match category keywords
        for cat, keywords in CATEGORY_KEYWORDS.items():
            for kw in keywords:
                if kw in text_lower:
                    detected_category = cat
                    break
            if detected_category != "Electronics":
                break

        # Attempt to clean lines to find a plausible product name
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        candidate_name = ""
        for line in lines:
            # Avoid lines that are just numbers/prices
            if not re.match(r'^[\$\d\.,\s€₹£¥]+$', line) and len(line) > 3:
                # Remove price tokens from title
                cleaned_line = re.sub(r'[\$₹€£¥]\s*[0-9]+(?:\.[0-9]+)?', '', line, flags=re.IGNORECASE).strip()
                if cleaned_line:
                    candidate_name = cleaned_line
                    break

        if not candidate_name or len(candidate_name) < 3:
            candidate_name = "Detected Product"

        # Cap length
        candidate_name = candidate_name[:50]
        return candidate_name, detected_category

    @classmethod
    def process_image(cls, image_path: str, filename: str) -> Dict[str, Any]:
        """
        Execute full OCR pipeline and return structured result.
        """
        raw_text, ocr_conf = cls.extract_text(image_path)
        price, currency, price_conf = cls.parse_price_and_currency(raw_text)
        product_name, category = cls.infer_product_details(raw_text)

        overall_confidence = round((ocr_conf * 0.4) + (price_conf * 0.6), 2) if (ocr_conf > 0 or price_conf > 0) else 0.2

        is_low_conf = (price is None) or (currency is None) or (overall_confidence < 0.70)
        warning_msg = None
        if is_low_conf:
            warning_msg = "OCR confidence is low or price/currency could not be automatically verified. Please verify the detected price and currency."

        return {
            "raw_text": raw_text or "No text recognized",
            "price": price,
            "currency": currency or "USD",
            "confidence": overall_confidence,
            "product_name_suggestion": product_name,
            "category_suggestion": category,
            "is_low_confidence": is_low_conf,
            "warning_message": warning_msg,
            "image_url": f"/uploads/{filename}"
        }
