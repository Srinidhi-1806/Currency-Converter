import logging
from typing import Dict, Any, Optional, List
from sqlalchemy.orm import Session
from app.models.ppp import PPPIndex

logger = logging.getLogger("app.services.ppp")

DEFAULT_CATEGORY_FACTORS = {
    "Electronics": 0.82,     # Tech items have specific local market elasticity & import tariff contexts
    "Food": 0.35,            # Food and dining have strong local purchasing power differences
    "Groceries": 0.40,       # Daily staples have distinct local cost structures
    "Fashion": 0.65,         # Apparel has moderate local manufacturing / retail factors
    "Beauty": 0.70,          # Skincare & cosmetics
    "Healthcare": 0.30,      # Pharmaceuticals & healthcare
    "Travel": 0.55,          # Domestic travel & hospitality
    "Household": 0.60,       # Home goods & utilities
    "Education": 0.45,       # Books, courses & learning material
    "Entertainment": 0.75,   # Subscriptions & gaming
    "Other": 0.70
}

class PPPService:
    @staticmethod
    def get_ppp_factor(
        db: Session,
        country: str = "India",
        category: str = "Electronics",
        currency: str = "INR"
    ) -> Dict[str, Any]:
        """
        Lookup category-aware Purchasing Power Parity (PPP) factor.
        """
        country_clean = country.strip().title() if country else "India"
        category_clean = category.strip().title() if category else "Electronics"
        currency_clean = currency.strip().upper() if currency else "INR"

        # Query database for exact country + category match
        record = db.query(PPPIndex).filter(
            PPPIndex.country.ilike(country_clean),
            PPPIndex.category.ilike(category_clean)
        ).first()

        if record:
            return {
                "country": record.country,
                "currency": record.currency,
                "category": record.category,
                "ppp_factor": record.ppp_factor,
                "reference_country": record.reference_country,
                "source": record.source,
                "source_year": record.source_year,
                "is_category_specific": True,
                "disclaimer": "The purchasing-power adjustment is an analytical estimate used to contextualize the product price. It is not an official consumer price or government PPP measurement."
            }

        # Fallback to category default or standard factor
        default_factor = DEFAULT_CATEGORY_FACTORS.get(category_clean, 0.75) if country_clean == "India" else 1.0
        return {
            "country": country_clean,
            "currency": currency_clean,
            "category": category_clean,
            "ppp_factor": default_factor,
            "reference_country": "USA",
            "source": "Analytical Category PPP Model (Default Benchmark)",
            "source_year": 2024,
            "is_category_specific": True,
            "disclaimer": "The purchasing-power adjustment is an analytical estimate used to contextualize the product price. It is not an official consumer price or government PPP measurement."
        }

    @staticmethod
    def calculate_effective_value(converted_price: float, ppp_factor: float) -> float:
        """
        Effective Product Value = Converted Price * PPP Factor
        """
        return round(converted_price * ppp_factor, 2)
