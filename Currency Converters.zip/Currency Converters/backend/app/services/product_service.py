import re
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from app.models.product import Category, Product

DEFAULT_CATEGORIES = [
    {"name": "Electronics", "description": "Phones, laptops, audio, accessories, and gadgets", "icon": "headphones"},
    {"name": "Fashion", "description": "Clothing, footwear, apparel, and wearables", "icon": "shirt"},
    {"name": "Food", "description": "Dining, restaurants, takeaway, and specialty food", "icon": "utensils"},
    {"name": "Groceries", "description": "Daily staples, supermarket items, produce, household supplies", "icon": "shopping-cart"},
    {"name": "Beauty", "description": "Skincare, cosmetics, fragrances, personal grooming", "icon": "sparkles"},
    {"name": "Healthcare", "description": "Medicines, wellness, fitness equipment, diagnostics", "icon": "heart-pulse"},
    {"name": "Travel", "description": "Flights, hotels, transportation, tours, vacation bookings", "icon": "plane"},
    {"name": "Household", "description": "Appliances, furniture, kitchenware, home improvement", "icon": "home"},
    {"name": "Education", "description": "Books, courses, tuition, certificates, learning materials", "icon": "book-open"},
    {"name": "Entertainment", "description": "Gaming, subscriptions, events, movies, streaming", "icon": "film"},
    {"name": "Other", "description": "General consumer goods and miscellaneous purchases", "icon": "package"}
]

SUBCATEGORY_RULES = {
    "Electronics": {
        "Audio": ["headphone", "earbuds", "speaker", "earphone", "soundbar", "mic"],
        "Computers": ["laptop", "pc", "desktop", "macbook", "monitor", "keyboard", "mouse"],
        "Mobile": ["iphone", "smartphone", "android", "phone", "tablet", "ipad"],
        "Wearables": ["smartwatch", "fitness tracker", "band"],
        "Gaming": ["playstation", "xbox", "nintendo", "console", "controller"]
    },
    "Fashion": {
        "Footwear": ["shoes", "sneakers", "boots", "sandals"],
        "Apparel": ["shirt", "t-shirt", "jeans", "jacket", "hoodie", "dress", "suit"],
        "Accessories": ["watch", "bag", "wallet", "belt", "sunglasses"]
    },
    "Groceries": {
        "Produce": ["fruits", "vegetables", "salad"],
        "Dairy": ["milk", "cheese", "butter", "yogurt"],
        "Pantry": ["rice", "flour", "oil", "spices", "pasta", "cereal"]
    }
}

class ProductService:
    @staticmethod
    def identify_subcategory(category: str, product_name: str) -> Optional[str]:
        if not product_name:
            return None
        
        name_lower = product_name.lower()
        cat_sub = SUBCATEGORY_RULES.get(category, {})
        for sub, keywords in cat_sub.items():
            for kw in keywords:
                if kw in name_lower:
                    return sub
        return "General " + category

    @staticmethod
    def get_or_create_product(
        db: Session,
        name: str,
        category: str,
        subcategory: Optional[str] = None,
        image_path: Optional[str] = None
    ) -> Product:
        prod = db.query(Product).filter(Product.name.ilike(name.strip())).first()
        if prod:
            return prod
        
        if not subcategory:
            subcategory = ProductService.identify_subcategory(category, name)
            
        new_prod = Product(
            name=name.strip(),
            category=category.strip(),
            subcategory=subcategory,
            image_path=image_path
        )
        db.add(new_prod)
        db.commit()
        db.refresh(new_prod)
        return new_prod
