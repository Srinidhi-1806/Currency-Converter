from typing import Dict, Any, Optional

class RecommendationService:
    @staticmethod
    def generate_recommendation(
        product_name: str,
        category: str,
        budget_impact: float,
        score: int,
        status: str,
        decision: str,
        effective_value: float,
        safe_budget_price: float,
        currency_symbol: str = "₹"
    ) -> str:
        """
        Generate contextual, intelligent recommendation text explaining WHY and what action to take.
        """
        diff = round(effective_value - safe_budget_price, 2)

        if decision == "BUY":
            if budget_impact <= 10.0:
                return (
                    f"Excellent purchase! '{product_name}' utilizes only {budget_impact:.1f}% of your disposable monthly budget. "
                    f"At {currency_symbol}{effective_value:,.2f} effective value, it has negligible impact on your monthly savings and is highly affordable."
                )
            else:
                return (
                    f"'{product_name}' is comfortably within your financial boundaries, consuming approximately {budget_impact:.1f}% of your disposable budget. "
                    f"Based on purchasing-power adjustment for {category}, proceeding with this purchase is financially sound."
                )

        elif decision == "CONSIDER":
            if diff > 0:
                return (
                    f"'{product_name}' represents approximately {budget_impact:.1f}% of your current disposable monthly budget. "
                    f"Based on the purchasing-power-adjusted value of {currency_symbol}{effective_value:,.2f}, it is affordable but will have a moderate impact on your monthly spending. "
                    f"It exceeds your conservative safe budget threshold by {currency_symbol}{diff:,.2f}. Review your upcoming expenses before deciding."
                )
            else:
                return (
                    f"'{product_name}' represents {budget_impact:.1f}% of your disposable budget. "
                    f"It falls within acceptable limits for {category}, but evaluate whether this purchase aligns with your immediate priority goals."
                )

        elif decision == "WAIT":
            return (
                f"Caution advised: '{product_name}' would consume {budget_impact:.1f}% of your disposable monthly budget. "
                f"Although the converted nominal price may seem approachable, its effective impact ({currency_symbol}{effective_value:,.2f}) places high pressure on your discretionary reserves. "
                f"Consider postponing the purchase to next month or saving up gradually. Recommended target budget for this category is under {currency_symbol}{safe_budget_price:,.2f}."
            )

        else: # NOT RECOMMENDED
            if safe_budget_price > 0:
                return (
                    f"Not recommended at this time. This purchase exceeds {budget_impact:.1f}% of your monthly disposable budget, creating severe financial strain. "
                    f"Your conservative budget-safe limit is {currency_symbol}{safe_budget_price:,.2f} (a difference of {currency_symbol}{diff:,.2f}). "
                    f"Look for a viable alternative within {currency_symbol}{safe_budget_price:,.2f} or build a dedicated savings buffer."
                )
            else:
                return (
                    f"Not recommended. You currently have zero or negative disposable monthly budget after factoring in fixed expenses and commitments. "
                    f"Any discretionary purchase will directly impact your essential living requirements or increase debt."
                )
