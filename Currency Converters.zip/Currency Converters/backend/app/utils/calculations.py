from typing import Tuple, Dict, Any, List

def calculate_disposable_budget(
    monthly_income: float,
    fixed_expenses: float = 0.0,
    variable_expenses: float = 0.0,
    commitments: float = 0.0
) -> float:
    return max(0.0, monthly_income - (fixed_expenses + variable_expenses + commitments))

def calculate_effective_product_value(
    converted_price: float,
    ppp_factor: float
) -> float:
    return round(converted_price * ppp_factor, 2)

def calculate_budget_impact(
    effective_value: float,
    disposable_budget: float
) -> float:
    if disposable_budget <= 0:
        return 999.9  # extreme impact when no budget exists
    impact = (effective_value / disposable_budget) * 100.0
    return round(impact, 2)

def calculate_affordability_score(
    effective_value: float,
    disposable_budget: float,
    monthly_income: float = None
) -> int:
    """
    Transparent deterministic Affordability Score (0 to 100).
    Algorithm:
    - If disposable_budget <= 0: Score = 0
    - If budget_impact > 100%: Score is linearly scaled down between 0 and 15
    - If budget_impact <= 10%: Score is in 90-100 (Highly Affordable)
    - If budget_impact 10%-25%: Score is in 75-89 (Affordable)
    - If budget_impact 25%-50%: Score is in 50-74 (Moderate Affordability)
    - If budget_impact 50%-80%: Score is in 25-49 (High Budget Impact)
    - If budget_impact 80%-100%: Score is in 15-24 (Very Difficult to Afford)
    """
    if disposable_budget <= 0:
        return 0

    impact = (effective_value / disposable_budget) * 100.0

    if impact > 100.0:
        # Score rapidly drops to 0-15 as it exceeds budget
        overshoot = min(impact - 100.0, 100.0)
        score = max(0, int(15 - (overshoot / 100.0) * 15))
    elif impact >= 80.0:
        # 80% - 100% impact -> Score 15 - 24
        normalized = (impact - 80.0) / 20.0
        score = int(24 - normalized * 9)
    elif impact >= 50.0:
        # 50% - 80% impact -> Score 25 - 49
        normalized = (impact - 50.0) / 30.0
        score = int(49 - normalized * 24)
    elif impact >= 25.0:
        # 25% - 50% impact -> Score 50 - 74
        normalized = (impact - 25.0) / 25.0
        score = int(74 - normalized * 24)
    elif impact >= 10.0:
        # 10% - 25% impact -> Score 75 - 89
        normalized = (impact - 10.0) / 15.0
        score = int(89 - normalized * 14)
    else:
        # 0% - 10% impact -> Score 90 - 100
        normalized = impact / 10.0
        score = int(100 - normalized * 10)

    return max(0, min(100, score))

def classify_affordability(score: int, budget_impact: float, disposable_budget: float) -> Tuple[str, str]:
    """
    Returns (status_label, decision)
    Statuses:
    - 81–100: Highly Affordable -> BUY
    - 61–80:  Affordable -> BUY / CONSIDER
    - 41–60:  Moderate Affordability -> CONSIDER
    - 21–40:  High Budget Impact -> WAIT
    - 0–20:   Very Difficult to Afford -> NOT RECOMMENDED
    """
    if disposable_budget <= 0:
        return ("No Disposable Budget", "NOT RECOMMENDED")
    
    if score >= 81:
        return ("Highly Affordable", "BUY")
    elif score >= 61:
        return ("Affordable", "BUY" if budget_impact <= 20 else "CONSIDER")
    elif score >= 41:
        return ("Moderate Affordability", "CONSIDER")
    elif score >= 21:
        return ("High Budget Impact", "WAIT")
    else:
        return ("Very Difficult to Afford", "NOT RECOMMENDED")

def calculate_safe_budget_price(
    disposable_budget: float,
    safe_percentage: float = 20.0
) -> float:
    if disposable_budget <= 0:
        return 0.0
    return round(disposable_budget * (safe_percentage / 100.0), 2)
