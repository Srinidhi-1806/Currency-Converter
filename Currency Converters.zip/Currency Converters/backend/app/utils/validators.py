import os
import re
from pathlib import Path
from fastapi import HTTPException, UploadFile
from app.config import settings

def validate_image_file(file: UploadFile) -> None:
    # Check extension
    filename = file.filename or ""
    ext = filename.split(".")[-1].lower() if "." in filename else ""
    if ext not in settings.ALLOWED_IMAGE_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported image type: '.{ext}'. Allowed formats: {', '.join(settings.ALLOWED_IMAGE_EXTENSIONS)}"
        )

def sanitize_filename(filename: str) -> str:
    # Remove path traversal characters and unsafe characters
    cleaned = re.sub(r"[^\w\.-]", "_", filename)
    return cleaned

def validate_positive_number(value: float, field_name: str) -> float:
    if value is None or value <= 0:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid {field_name}: value must be a positive number greater than 0."
        )
    return value
