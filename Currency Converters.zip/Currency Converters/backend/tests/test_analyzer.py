import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from app.utils.calculations import (
    calculate_disposable_budget,
    calculate_effective_product_value,
    calculate_budget_impact,
    calculate_affordability_score,
    classify_affordability,
    calculate_safe_budget_price,
)
from app.services.ocr_service import OCRService
from app.services.recommendation_service import RecommendationService

def test_budget_calculations():
    income = 40000.0
    fixed = 18000.0
    variable = 7000.0
    commitments = 5000.0
    disposable = calculate_disposable_budget(income, fixed, variable, commitments)
    assert disposable == 10000.0

def test_ppp_effective_value():
    converted_price = 4200.0
    factor = 0.82
    effective = calculate_effective_product_value(converted_price, factor)
    assert effective == 3444.0

def test_budget_impact():
    effective = 3500.0
    disposable = 10000.0
    impact = calculate_budget_impact(effective, disposable)
    assert impact == 35.0

def test_affordability_score():
    score = calculate_affordability_score(3500.0, 10000.0, 40000.0)
    assert 60 <= score <= 75
    status, decision = classify_affordability(score, 35.0, 10000.0)
    assert status in ("Affordable", "Moderate Affordability")
    assert decision in ("BUY", "CONSIDER")

def test_safe_budget_threshold():
    disposable = 10000.0
    safe_price = calculate_safe_budget_price(disposable, 20.0)
    assert safe_price == 2000.0

def test_ocr_regex_parsing():
    price, curr, conf = OCRService.parse_price_and_currency("Sony Wireless Headphones $49.99 Special Offer")
    assert price == 49.99
    assert curr == "USD"
    assert conf > 0.8

    price2, curr2, _ = OCRService.parse_price_and_currency("Boat Rockerz ₹2,499 Limited Edition")
    assert price2 == 2499.0
    assert curr2 == "INR"

    price3, curr3, _ = OCRService.parse_price_and_currency("Euro Spec Item €29.99")
    assert price3 == 29.99
    assert curr3 == "EUR"

def test_recommendation_generation():
    rec = RecommendationService.generate_recommendation(
        product_name="Sony Headphones",
        category="Electronics",
        budget_impact=35.0,
        score=65,
        status="Affordable",
        decision="CONSIDER",
        effective_value=3500.0,
        safe_budget_price=2000.0
    )
    assert "Sony Headphones" in rec
    assert "35.0%" in rec
