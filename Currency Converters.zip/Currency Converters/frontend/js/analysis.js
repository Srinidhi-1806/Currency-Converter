/**
 * Analysis Wizard & Decision Dashboard Controller
 */

let currentStep = 1;
const TOTAL_STEPS = 6;

const LOADING_MESSAGES = [
  "Validating product information...",
  "Extracting price and currency context...",
  "Fetching live real-time exchange rate...",
  "Applying category-aware PPP adjustment factor...",
  "Evaluating personal monthly budget cashflow...",
  "Computing deterministic affordability score...",
  "Formulating personalized purchase decision recommendation..."
];

function initAnalysisWizard() {
  currentStep = 1;
  updateWizardUI();

  // Wizard navigation buttons
  const btnToStep2 = document.getElementById('btnToStep2');
  const btnToStep3 = document.getElementById('btnToStep3');
  const btnToStep4 = document.getElementById('btnToStep4');
  const btnExecuteAnalysis = document.getElementById('btnExecuteAnalysis');
  const btnReanalyze = document.getElementById('btnReanalyze');

  if (btnToStep2) btnToStep2.addEventListener('click', () => goToStep(2));
  if (btnToStep3) btnToStep3.addEventListener('click', validateAndGoToStep3);
  if (btnToStep4) btnToStep4.addEventListener('click', () => goToStep(4));
  if (btnExecuteAnalysis) btnExecuteAnalysis.addEventListener('click', executeCompleteAnalysis);
  if (btnReanalyze) btnReanalyze.addEventListener('click', () => goToStep(1));

  // Initialize upload dropzone
  if (typeof initUploadZone === 'function') {
    initUploadZone();
  }

  // Pre-fill user budget info in step 4
  loadStep4BudgetDefaults();
}

function goToStep(stepNumber) {
  if (stepNumber < 1 || stepNumber > TOTAL_STEPS) return;
  currentStep = stepNumber;
  updateWizardUI();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

window.goToStep = goToStep;

function updateWizardUI() {
  // Update step bubbles and progress line
  const progressLine = document.getElementById('stepWizardProgress');
  if (progressLine) {
    const percent = ((currentStep - 1) / (TOTAL_STEPS - 1)) * 100;
    progressLine.style.width = `${percent}%`;
  }

  for (let i = 1; i <= TOTAL_STEPS; i++) {
    const stepEl = document.getElementById(`stepItem${i}`);
    const panelEl = document.getElementById(`stepPanel${i}`);

    if (stepEl) {
      stepEl.classList.remove('active', 'completed');
      if (i < currentStep) {
        stepEl.classList.add('completed');
      } else if (i === currentStep) {
        stepEl.classList.add('active');
      }
    }

    if (panelEl) {
      panelEl.style.display = i === currentStep ? 'block' : 'none';
    }
  }
}

function validateAndGoToStep3() {
  const price = parseFloat(document.getElementById('detectedPrice')?.value);
  if (!price || price <= 0) {
    showToast('Please enter a valid product price greater than 0.', 'error');
    document.getElementById('detectedPrice')?.focus();
    return;
  }
  goToStep(3);
}

async function loadStep4BudgetDefaults() {
  try {
    const res = await fetch(`${API_BASE}/budget?user_id=1`);
    if (res.ok) {
      const budget = await res.json();
      const incomeEl = document.getElementById('reviewIncome');
      const dispEl = document.getElementById('reviewDisposable');
      const currEl = document.getElementById('reviewCurrency');

      if (incomeEl) incomeEl.innerText = formatCurrency(budget.monthly_income, budget.currency);
      if (dispEl) dispEl.innerText = formatCurrency(budget.disposable_budget, budget.currency);
      if (currEl) currEl.innerText = budget.currency;

      // Keep hidden inputs in sync
      const hiddenDisp = document.getElementById('customDisposableBudget');
      if (hiddenDisp) hiddenDisp.value = budget.disposable_budget;
    }
  } catch (err) {
    console.warn('Budget default sync notice:', err);
  }
}

async function executeCompleteAnalysis() {
  // Show Step 5 Loading State
  goToStep(5);
  startLoadingTicker();

  // Collect Payload
  const productName = document.getElementById('productName')?.value || 'Sample Product';
  const price = parseFloat(document.getElementById('detectedPrice')?.value) || 49.99;
  const currency = document.getElementById('detectedCurrency')?.value || 'USD';
  const category = document.getElementById('productCategory')?.value || 'Electronics';
  const country = document.getElementById('userCountry')?.value || 'India';
  const targetCurrency = document.getElementById('userHomeCurrency')?.value || 'INR';
  const customDisposable = parseFloat(document.getElementById('customDisposableBudget')?.value) || null;

  const payload = {
    user_id: 1,
    product_name: productName,
    category: category,
    original_price: price,
    original_currency: currency,
    target_currency: targetCurrency,
    country: country,
    disposable_budget: customDisposable,
    image_path: window.currentUploadedImageUrl || null,
    raw_ocr_text: document.getElementById('ocrRawText')?.innerText || null
  };

  try {
    const startTime = Date.now();
    const res = await fetch(`${API_BASE}/analysis`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.detail || 'Analysis calculation failed.');
    }

    const data = await res.json();
    window.AppState.activeAnalysis = data;
    try {
      localStorage.setItem('latest_analysis_id', data.id);
      const openResultBtn = document.getElementById('btnOpenResultTab');
      if (openResultBtn) {
        openResultBtn.href = `result.html?id=${data.id}`;
      }
    } catch (e) {}

    // Ensure smooth presentation by giving user time to see stages
    const elapsed = Date.now() - startTime;
    const waitTime = Math.max(0, 1200 - elapsed);

    setTimeout(() => {
      renderAnalysisDashboard(data);
      goToStep(6);
    }, waitTime);

  } catch (err) {
    console.error('Analysis error:', err);
    showToast(err.message || 'An error occurred during analysis.', 'error', 6000);
    goToStep(4);
  }
}

function startLoadingTicker() {
  const tickerEl = document.getElementById('loadingTicker');
  if (!tickerEl) return;

  let msgIndex = 0;
  tickerEl.innerText = LOADING_MESSAGES[0];

  const interval = setInterval(() => {
    msgIndex++;
    if (msgIndex < LOADING_MESSAGES.length && currentStep === 5) {
      tickerEl.innerText = LOADING_MESSAGES[msgIndex];
    } else {
      clearInterval(interval);
    }
  }, 350);
}

function renderAnalysisDashboard(data) {
  const sym = getCurrencySymbol(data.target_currency);
  const origSym = getCurrencySymbol(data.original_currency);

  // 1. Decision Banner
  const decisionBanner = document.getElementById('resultDecisionBanner');
  const decisionBadge = document.getElementById('resultDecisionBadge');
  const decisionTitle = document.getElementById('resultDecisionTitle');
  const decisionIcon = document.getElementById('resultDecisionIcon');

  if (decisionBanner) {
    decisionBanner.className = `decision-banner decision-${data.decision.toLowerCase().replace(/_/g, '-')}`;
  }
  if (decisionBadge) decisionBadge.innerText = data.decision;
  if (decisionTitle) decisionTitle.innerText = `${data.affordability_status}`;

  const iconClasses = {
    BUY: 'bi-check2-circle',
    CONSIDER: 'bi-info-circle',
    WAIT: 'bi-hourglass-split',
    'NOT RECOMMENDED': 'bi-shield-x'
  };
  if (decisionIcon) {
    decisionIcon.innerHTML = `<i class="bi ${iconClasses[data.decision] || 'bi-info-circle'}"></i>`;
  }

  // 2. Score Meter Circular SVG
  const scoreValEl = document.getElementById('resultScoreValue');
  const scoreMeterProgress = document.getElementById('scoreMeterProgress');
  if (scoreValEl) scoreValEl.innerText = data.affordability_score;
  if (scoreMeterProgress) {
    const radius = 45;
    const circumference = 2 * Math.PI * radius;
    scoreMeterProgress.style.strokeDasharray = `${circumference}`;
    const offset = circumference - (data.affordability_score / 100) * circumference;
    scoreMeterProgress.style.strokeDashoffset = `${offset}`;

    // Color stroke according to score
    if (data.affordability_score >= 80) scoreMeterProgress.style.stroke = '#10b981';
    else if (data.affordability_score >= 60) scoreMeterProgress.style.stroke = '#3b82f6';
    else if (data.affordability_score >= 40) scoreMeterProgress.style.stroke = '#f59e0b';
    else scoreMeterProgress.style.stroke = '#ef4444';
  }

  // 3. Recommendation Statement
  const recEl = document.getElementById('resultRecommendationText');
  if (recEl) recEl.innerText = data.recommendation;

  // 4. Price Transformation Waterfall Cards
  const origPriceEl = document.getElementById('resultOriginalPrice');
  const convPriceEl = document.getElementById('resultConvertedPrice');
  const effValueEl = document.getElementById('resultEffectiveValue');
  const rateInfoEl = document.getElementById('resultRateInfo');
  const pppFactorEl = document.getElementById('resultPPPFactor');

  if (origPriceEl) origPriceEl.innerText = `${origSym}${data.original_price.toLocaleString()} ${data.original_currency}`;
  if (convPriceEl) convPriceEl.innerText = `${sym}${data.converted_price.toLocaleString()} ${data.target_currency}`;
  if (effValueEl) effValueEl.innerText = `${sym}${data.effective_value.toLocaleString()} ${data.target_currency}`;
  if (rateInfoEl) {
    rateInfoEl.innerText = `1 ${data.original_currency} = ${data.exchange_rate.toFixed(4)} ${data.target_currency} ${data.is_rate_cached ? '(Cached)' : '(Live)'}`;
  }
  if (pppFactorEl) pppFactorEl.innerText = `PPP Factor: ${data.ppp_factor.toFixed(2)} (${data.category})`;

  // 5. Budget Impact & Progress Bar
  const budgetImpactValEl = document.getElementById('resultBudgetImpactVal');
  const budgetProgressFill = document.getElementById('resultBudgetProgressFill');
  const dispBudgetEl = document.getElementById('resultDisposableBudget');
  const remainBudgetEl = document.getElementById('resultRemainingBudget');

  if (budgetImpactValEl) budgetImpactValEl.innerText = `${data.budget_impact.toFixed(1)}%`;
  if (dispBudgetEl) dispBudgetEl.innerText = `${sym}${data.disposable_budget.toLocaleString()}`;
  if (remainBudgetEl) remainBudgetEl.innerText = `${sym}${data.remaining_disposable_budget.toLocaleString()}`;

  if (budgetProgressFill) {
    const cappedImpact = Math.min(100, data.budget_impact);
    budgetProgressFill.style.width = `${cappedImpact}%`;
    if (data.budget_impact > 80) budgetProgressFill.style.background = '#ef4444';
    else if (data.budget_impact > 50) budgetProgressFill.style.background = '#f59e0b';
    else if (data.budget_impact > 20) budgetProgressFill.style.background = '#3b82f6';
    else budgetProgressFill.style.background = '#10b981';
  }

  // 6. Safe Budget Analysis
  const safeThresholdPriceEl = document.getElementById('resultSafeBudgetPrice');
  const safeDiffEl = document.getElementById('resultSafeDiff');
  if (safeThresholdPriceEl) safeThresholdPriceEl.innerText = `${sym}${data.safe_budget_price.toLocaleString()}`;
  if (safeDiffEl) {
    if (data.price_difference_safe > 0) {
      safeDiffEl.innerHTML = `<span class="text-danger">${sym}${data.price_difference_safe.toLocaleString()} above safe limit</span>`;
    } else {
      safeDiffEl.innerHTML = `<span class="text-success">${sym}${Math.abs(data.price_difference_safe).toLocaleString()} within safe limit</span>`;
    }
  }

  // 7. Render Mathematical Accordion Steps
  renderBreakdownAccordion(data.calculation_breakdown?.breakdown_steps || []);

  // 8. Render Visualizations
  renderDashboardVisualizations(data);
}

function renderBreakdownAccordion(steps) {
  const container = document.getElementById('calculationStepsAccordion');
  if (!container) return;

  if (!steps || steps.length === 0) {
    container.innerHTML = '<p class="text-muted">Breakdown details available in full analysis.</p>';
    return;
  }

  container.innerHTML = steps.map((step, idx) => `
    <div class="accordion-item">
      <div class="accordion-header" onclick="toggleAccordionItem(${idx})">
        <div class="accordion-title-wrap">
          <span class="badge badge-primary">Step ${step.step_number}</span>
          <span>${step.title}</span>
        </div>
        <div style="display:flex;align-items:center;gap:0.75rem;">
          <strong style="color:var(--accent-secondary);font-family:var(--font-mono);">${step.result}</strong>
          <i class="bi bi-chevron-down" id="accIcon${idx}"></i>
        </div>
      </div>
      <div class="accordion-body" id="accBody${idx}">
        <div class="calc-formula-box">${step.formula}</div>
        <p style="font-size:0.88rem;color:var(--text-secondary);">${step.explanation}</p>
      </div>
    </div>
  `).join('');
}

function toggleAccordionItem(idx) {
  const body = document.getElementById(`accBody${idx}`);
  const icon = document.getElementById(`accIcon${idx}`);
  if (!body) return;

  const isOpen = body.classList.contains('open');
  if (isOpen) {
    body.classList.remove('open');
    if (icon) icon.className = 'bi bi-chevron-down';
  } else {
    body.classList.add('open');
    if (icon) icon.className = 'bi bi-chevron-up';
  }
}

window.toggleAccordionItem = toggleAccordionItem;
