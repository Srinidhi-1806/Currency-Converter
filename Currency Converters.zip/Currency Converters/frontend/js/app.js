/**
 * Context-Aware Product Value & Personal Affordability Analyzer
 * Global Core App & Utilities
 */

const API_BASE = (window.location.hostname === '127.0.0.1' || window.location.hostname === 'localhost') && window.location.port !== '8000' && window.location.port !== ''
  ? `http://${window.location.hostname}:8000/api`
  : (window.location.protocol === 'file:' ? 'http://127.0.0.1:8000/api' : '/api');

// Global State
window.AppState = {
  currencies: [],
  categories: [],
  userBudget: null,
  activeAnalysis: null,
};

// Toast Notification System
function showToast(message, type = 'info', duration = 4000) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const iconMap = {
    success: 'bi-check-circle-fill text-success',
    error: 'bi-exclamation-triangle-fill text-danger',
    warning: 'bi-exclamation-circle-fill text-warning',
    info: 'bi-info-circle-fill text-info'
  };

  toast.innerHTML = `
    <i class="bi ${iconMap[type] || iconMap.info}"></i>
    <div style="flex: 1; font-size: 0.9rem;">${message}</div>
    <button type="button" style="background:none;border:none;color:#94a3b8;cursor:pointer;" onclick="this.parentElement.remove()">
      <i class="bi bi-x"></i>
    </button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// Currency Symbol Map
const CURRENCY_SYMBOLS = {
  INR: '₹',
  USD: '$',
  EUR: '€',
  GBP: '£',
  JPY: '¥',
  CAD: 'C$',
  AUD: 'A$',
  AED: 'د.إ',
  SGD: 'S$'
};

function getCurrencySymbol(code) {
  return CURRENCY_SYMBOLS[(code || 'INR').toUpperCase()] || (code || '₹');
}

function formatCurrency(amount, code = 'INR') {
  const sym = getCurrencySymbol(code);
  const num = Number(amount) || 0;
  return `${sym}${num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatPercent(value) {
  const num = Number(value) || 0;
  return `${num.toFixed(1)}%`;
}

// Fetch Initial Global Data
async function loadGlobalMetadata() {
  try {
    const [currRes, catRes, budgetRes] = await Promise.all([
      fetch(`${API_BASE}/currencies`).catch(() => null),
      fetch(`${API_BASE}/products/categories`).catch(() => null),
      fetch(`${API_BASE}/budget?user_id=1`).catch(() => null)
    ]);

    if (currRes && currRes.ok) {
      window.AppState.currencies = await currRes.json();
    }
    if (catRes && catRes.ok) {
      window.AppState.categories = await catRes.json();
    }
    if (budgetRes && budgetRes.ok) {
      window.AppState.userBudget = await budgetRes.json();
    }
  } catch (err) {
    console.warn('Metadata load notice:', err);
  }
}

// Mobile navigation drawer toggle
document.addEventListener('DOMContentLoaded', () => {
  loadGlobalMetadata();

  const toggleBtn = document.getElementById('mobileNavToggle');
  const navDrawer = document.getElementById('mobileNavDrawer');
  if (toggleBtn && navDrawer) {
    toggleBtn.addEventListener('click', () => {
      const isHidden = navDrawer.style.display === 'none' || !navDrawer.style.display;
      navDrawer.style.display = isHidden ? 'flex' : 'none';
    });
  }
});
