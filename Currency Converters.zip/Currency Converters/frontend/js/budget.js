/**
 * Personal Budget Profile Module
 */

let budgetDonutChart = null;

function initBudgetPage() {
  const form = document.getElementById('budgetProfileForm');
  const incomeInput = document.getElementById('budgetIncome');
  const fixedInput = document.getElementById('budgetFixed');
  const variableInput = document.getElementById('budgetVariable');
  const commitmentsInput = document.getElementById('budgetCommitments');
  const currencySelect = document.getElementById('budgetCurrency');

  // Attach live calculation listener to all budget inputs
  [incomeInput, fixedInput, variableInput, commitmentsInput, currencySelect].forEach(input => {
    if (input) {
      input.addEventListener('input', updateLiveBudgetCalculation);
    }
  });

  // Load existing profile from backend
  loadBudgetProfile();

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      await saveBudgetProfile();
    });
  }
}

async function loadBudgetProfile() {
  try {
    const res = await fetch(`${API_BASE}/budget?user_id=1`);
    if (res.ok) {
      const data = await res.json();
      window.AppState.userBudget = data;

      const incomeInput = document.getElementById('budgetIncome');
      const fixedInput = document.getElementById('budgetFixed');
      const variableInput = document.getElementById('budgetVariable');
      const commitmentsInput = document.getElementById('budgetCommitments');
      const currencySelect = document.getElementById('budgetCurrency');

      if (incomeInput) incomeInput.value = data.monthly_income;
      if (fixedInput) fixedInput.value = data.fixed_expenses;
      if (variableInput) variableInput.value = data.variable_expenses;
      if (commitmentsInput) commitmentsInput.value = data.commitments;
      if (currencySelect) currencySelect.value = data.currency;

      updateLiveBudgetCalculation();
    }
  } catch (err) {
    console.error('Failed to fetch budget:', err);
  }
}

function updateLiveBudgetCalculation() {
  const income = parseFloat(document.getElementById('budgetIncome')?.value) || 0;
  const fixed = parseFloat(document.getElementById('budgetFixed')?.value) || 0;
  const variable = parseFloat(document.getElementById('budgetVariable')?.value) || 0;
  const commitments = parseFloat(document.getElementById('budgetCommitments')?.value) || 0;
  const currency = document.getElementById('budgetCurrency')?.value || 'INR';

  const totalExpenses = fixed + variable + commitments;
  const disposable = Math.max(0, income - totalExpenses);
  const savingsRate = income > 0 ? ((commitments / income) * 100).toFixed(1) : 0;
  const safeThreshold = (disposable * 0.20).toFixed(2);

  // Update UI Display Elements
  const disposableEl = document.getElementById('dispBudgetPreview');
  const totalExpEl = document.getElementById('totalExpPreview');
  const savingsRateEl = document.getElementById('savingsRatePreview');
  const safeThresholdEl = document.getElementById('safeThresholdPreview');

  if (disposableEl) disposableEl.innerText = formatCurrency(disposable, currency);
  if (totalExpEl) totalExpEl.innerText = formatCurrency(totalExpenses, currency);
  if (savingsRateEl) savingsRateEl.innerText = `${savingsRate}%`;
  if (safeThresholdEl) safeThresholdEl.innerText = formatCurrency(safeThreshold, currency);

  // Update Donut Chart
  renderBudgetDonutChart(fixed, variable, commitments, disposable, currency);
}

function renderBudgetDonutChart(fixed, variable, commitments, disposable, currency) {
  const canvas = document.getElementById('budgetAllocationChart');
  if (!canvas || typeof Chart === 'undefined') return;

  const ctx = canvas.getContext('2d');
  if (budgetDonutChart) {
    budgetDonutChart.destroy();
  }

  budgetDonutChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Fixed Expenses', 'Variable Expenses', 'Commitments/Savings', 'Disposable Budget'],
      datasets: [{
        data: [fixed, variable, commitments, disposable],
        backgroundColor: [
          '#6366f1', // Indigo Purple
          '#f59e0b', // Radiant Amber
          '#06b6d4', // Azure Cyan
          '#10b981'  // Vibrant Emerald
        ],
        hoverBackgroundColor: [
          '#4f46e5',
          '#d97706',
          '#0891b2',
          '#059669'
        ],
        borderWidth: 3,
        borderColor: '#ffffff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: '#4f6055',
            font: { family: 'Plus Jakarta Sans', size: 11 }
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const val = context.raw || 0;
              return ` ${context.label}: ${formatCurrency(val, currency)}`;
            }
          }
        }
      },
      cutout: '70%'
    }
  });
}

async function saveBudgetProfile() {
  const income = parseFloat(document.getElementById('budgetIncome')?.value) || 0;
  const fixed = parseFloat(document.getElementById('budgetFixed')?.value) || 0;
  const variable = parseFloat(document.getElementById('budgetVariable')?.value) || 0;
  const commitments = parseFloat(document.getElementById('budgetCommitments')?.value) || 0;
  const currency = document.getElementById('budgetCurrency')?.value || 'INR';

  if (income <= 0) {
    showToast('Monthly income must be greater than 0.', 'error');
    return;
  }

  const payload = {
    user_id: 1,
    monthly_income: income,
    fixed_expenses: fixed,
    variable_expenses: variable,
    commitments: commitments,
    currency: currency
  };

  try {
    const res = await fetch(`${API_BASE}/budget`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      const data = await res.json();
      window.AppState.userBudget = data;
      showToast('Budget profile saved successfully!', 'success');
    } else {
      throw new Error('Failed to update budget profile.');
    }
  } catch (err) {
    showToast(err.message || 'Error saving budget.', 'error');
  }
}
