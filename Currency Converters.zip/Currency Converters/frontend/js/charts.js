/**
 * Visualizations & Chart.js Controllers with Radiant Linear Gradients
 */

let priceTransformChart = null;
let budgetImpactChart = null;
let budgetDistributionChart = null;

function renderDashboardVisualizations(analysis) {
  if (typeof Chart === 'undefined') {
    console.warn('Chart.js library is loading...');
    return;
  }

  const targetCurr = analysis.target_currency || 'INR';
  const sym = getCurrencySymbol(targetCurr);

  // 1. Chart 1: Price Transformation Waterfall
  renderPriceTransformChart(analysis, sym);

  // 2. Chart 2: Budget Impact & Safe Threshold
  renderBudgetImpactChart(analysis, sym);

  // 3. Chart 3: Monthly Budget Composition with Post-Purchase State
  renderBudgetDistributionChart(analysis, sym);
}

function renderPriceTransformChart(analysis, sym) {
  const canvas = document.getElementById('chartPriceTransform');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  if (priceTransformChart) priceTransformChart.destroy();

  const labels = [
    `Original (${analysis.original_currency})`,
    `Market Converted (${analysis.target_currency})`,
    `PPP Effective Value (${analysis.target_currency})`
  ];

  const dataValues = [
    analysis.original_price,
    analysis.converted_price,
    analysis.effective_value
  ];

  // Create Beautiful Canvas Linear Gradients
  const grad1 = ctx.createLinearGradient(0, 0, 0, 240);
  grad1.addColorStop(0, '#06b6d4');
  grad1.addColorStop(1, '#3b82f6');

  const grad2 = ctx.createLinearGradient(0, 0, 0, 240);
  grad2.addColorStop(0, '#6366f1');
  grad2.addColorStop(1, '#a855f7');

  const grad3 = ctx.createLinearGradient(0, 0, 0, 240);
  grad3.addColorStop(0, '#ec4899');
  grad3.addColorStop(1, '#f43f5e');

  priceTransformChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Price Transformation',
        data: dataValues,
        backgroundColor: [grad1, grad2, grad3],
        borderColor: ['#0284c7', '#7c3aed', '#db2777'],
        borderWidth: 1.5,
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(15, 23, 42, 0.9)',
          padding: 10,
          titleFont: { family: 'Plus Jakarta Sans', size: 12, weight: 'bold' },
          bodyFont: { family: 'JetBrains Mono', size: 12 },
          cornerRadius: 8,
          callbacks: {
            label: function(context) {
              const idx = context.dataIndex;
              const val = context.raw || 0;
              const curr = idx === 0 ? analysis.original_currency : analysis.target_currency;
              return ` ${context.label}: ${getCurrencySymbol(curr)}${val.toLocaleString()}`;
            }
          }
        }
      },
      scales: {
        x: {
          ticks: { color: '#475569', font: { family: 'Plus Jakarta Sans', size: 11, weight: '600' } },
          grid: { color: 'rgba(99, 102, 241, 0.06)' }
        },
        y: {
          ticks: {
            color: '#475569',
            font: { family: 'JetBrains Mono', size: 11 },
            callback: (v) => `${sym}${v}`
          },
          grid: { color: 'rgba(99, 102, 241, 0.06)' }
        }
      }
    }
  });
}

function renderBudgetImpactChart(analysis, sym) {
  const canvas = document.getElementById('chartBudgetImpact');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  if (budgetImpactChart) budgetImpactChart.destroy();

  const labels = ['Safe Limit (20%)', 'Product Value', 'Disposable Budget'];
  const dataValues = [
    analysis.safe_budget_price,
    analysis.effective_value,
    analysis.disposable_budget
  ];

  // Gradients
  const gradSafe = ctx.createLinearGradient(0, 0, 300, 0);
  gradSafe.addColorStop(0, '#10b981');
  gradSafe.addColorStop(1, '#059669');

  const gradDisp = ctx.createLinearGradient(0, 0, 300, 0);
  gradDisp.addColorStop(0, '#06b6d4');
  gradDisp.addColorStop(1, '#6366f1');

  const gradProduct = ctx.createLinearGradient(0, 0, 300, 0);
  let prodBorder = '#059669';

  if (analysis.effective_value > analysis.disposable_budget) {
    gradProduct.addColorStop(0, '#f43f5e');
    gradProduct.addColorStop(1, '#e11d48');
    prodBorder = '#be123c';
  } else if (analysis.effective_value > analysis.safe_budget_price) {
    gradProduct.addColorStop(0, '#f59e0b');
    gradProduct.addColorStop(1, '#ea580c');
    prodBorder = '#c2410c';
  } else {
    gradProduct.addColorStop(0, '#10b981');
    gradProduct.addColorStop(1, '#059669');
    prodBorder = '#047857';
  }

  budgetImpactChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Budget Impact Comparison',
        data: dataValues,
        backgroundColor: [
          gradSafe,
          gradProduct,
          gradDisp
        ],
        borderColor: [
          '#059669',
          prodBorder,
          '#4f46e5'
        ],
        borderWidth: 1.5,
        borderRadius: 8
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(15, 23, 42, 0.9)',
          padding: 10,
          titleFont: { family: 'Plus Jakarta Sans', size: 12, weight: 'bold' },
          bodyFont: { family: 'JetBrains Mono', size: 12 },
          cornerRadius: 8,
          callbacks: {
            label: (ctx) => ` ${ctx.label}: ${sym}${Number(ctx.raw).toLocaleString()}`
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: '#475569',
            font: { family: 'JetBrains Mono', size: 11 },
            callback: (v) => `${sym}${v}`
          },
          grid: { color: 'rgba(99, 102, 241, 0.06)' }
        },
        y: {
          ticks: { color: '#0f172a', font: { family: 'Plus Jakarta Sans', size: 11, weight: '700' } },
          grid: { color: 'rgba(99, 102, 241, 0.06)' }
        }
      }
    }
  });
}

function renderBudgetDistributionChart(analysis, sym) {
  const canvas = document.getElementById('chartBudgetDistribution');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  if (budgetDistributionChart) budgetDistributionChart.destroy();

  const income = analysis.monthly_income || 40000;
  const productCost = Math.min(analysis.effective_value, analysis.disposable_budget);
  const remaining = Math.max(0, analysis.disposable_budget - analysis.effective_value);
  const committedAndFixed = Math.max(0, income - analysis.disposable_budget);

  budgetDistributionChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Fixed & Committed', 'Product Cost', 'Remaining Cashflow'],
      datasets: [{
        data: [committedAndFixed, productCost, remaining],
        backgroundColor: [
          '#64748b', // Slate Gray
          '#ec4899', // Radiant Fuchsia Pink
          '#10b981'  // Vibrant Emerald
        ],
        hoverBackgroundColor: [
          '#475569',
          '#db2777',
          '#059669'
        ],
        borderWidth: 3,
        borderColor: '#ffffff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: '#334155', font: { family: 'Plus Jakarta Sans', size: 11, weight: '600' }, padding: 14 }
        },
        tooltip: {
          backgroundColor: 'rgba(15, 23, 42, 0.9)',
          padding: 10,
          titleFont: { family: 'Plus Jakarta Sans', size: 12, weight: 'bold' },
          bodyFont: { family: 'JetBrains Mono', size: 12 },
          cornerRadius: 8,
          callbacks: {
            label: (ctx) => ` ${ctx.label}: ${sym}${Number(ctx.raw).toLocaleString()}`
          }
        }
      },
      cutout: '68%'
    }
  });
}
