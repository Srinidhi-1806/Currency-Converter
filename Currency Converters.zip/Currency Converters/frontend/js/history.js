/**
 * Analysis History Module
 */

let historyItems = [];

function initHistoryPage() {
  const searchInput = document.getElementById('historySearchInput');
  const categoryFilter = document.getElementById('historyCategoryFilter');

  if (searchInput) searchInput.addEventListener('input', filterAndRenderHistory);
  if (categoryFilter) categoryFilter.addEventListener('change', filterAndRenderHistory);

  loadHistory();
}

async function loadHistory() {
  const tableBody = document.getElementById('historyTableBody');
  const emptyState = document.getElementById('historyEmptyState');

  try {
    const res = await fetch(`${API_BASE}/analysis/history?user_id=1`);
    if (res.ok) {
      historyItems = await res.json();
      filterAndRenderHistory();
    }
  } catch (err) {
    console.error('Failed to load history:', err);
    if (tableBody) tableBody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Failed to load history items.</td></tr>`;
  }
}

function filterAndRenderHistory() {
  const query = (document.getElementById('historySearchInput')?.value || '').toLowerCase();
  const category = document.getElementById('historyCategoryFilter')?.value || '';
  const tableBody = document.getElementById('historyTableBody');
  const emptyState = document.getElementById('historyEmptyState');

  const filtered = historyItems.filter(item => {
    const matchName = item.product_name.toLowerCase().includes(query);
    const matchCat = !category || item.category.toLowerCase() === category.toLowerCase();
    return matchName && matchCat;
  });

  if (!tableBody) return;

  if (filtered.length === 0) {
    tableBody.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';

  tableBody.innerHTML = filtered.map(item => {
    const sym = getCurrencySymbol(item.target_currency);
    const origSym = getCurrencySymbol(item.original_currency);
    const statusClass = item.decision === 'BUY' ? 'badge-success'
      : (item.decision === 'CONSIDER' ? 'badge-info'
      : (item.decision === 'WAIT' ? 'badge-warning' : 'badge-danger'));

    const dateStr = new Date(item.created_at).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric'
    });

    return `
      <tr>
        <td>
          <div style="font-weight:700;color:var(--text-primary);">${item.product_name}</div>
          <div style="font-size:0.78rem;color:var(--text-muted);">${dateStr}</div>
        </td>
        <td>
          <span class="badge badge-primary">${item.category}</span>
        </td>
        <td>
          <div>${origSym}${item.original_price.toLocaleString()} ${item.original_currency}</div>
          <div style="font-size:0.75rem;color:var(--text-muted);">→ ${sym}${item.converted_price.toLocaleString()}</div>
        </td>
        <td>
          <strong style="color:var(--accent-secondary);">${sym}${item.effective_value.toLocaleString()}</strong>
        </td>
        <td>
          <div>${item.budget_impact.toFixed(1)}%</div>
          <div style="font-size:0.75rem;color:var(--text-muted);">Score: ${item.affordability_score}/100</div>
        </td>
        <td>
          <span class="badge ${statusClass}">${item.decision}</span>
        </td>
        <td>
          <div style="display:flex;gap:0.5rem;">
            <a href="result.html?id=${item.id}" class="btn btn-sm btn-secondary" title="View Full Analysis">
              <i class="bi bi-eye"></i> View
            </a>
            <button class="btn btn-sm btn-outline" style="color:var(--color-danger);border-color:rgba(239,68,68,0.3);" onclick="deleteHistoryItem(${item.id})" title="Delete">
              <i class="bi bi-trash"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

async function deleteHistoryItem(id) {
  if (!confirm('Are you sure you want to remove this analysis from your history?')) return;

  try {
    const res = await fetch(`${API_BASE}/analysis/${id}`, { method: 'DELETE' });
    if (res.ok) {
      showToast('Analysis deleted successfully.', 'success');
      historyItems = historyItems.filter(i => i.id !== id);
      filterAndRenderHistory();
    } else {
      throw new Error('Failed to delete.');
    }
  } catch (err) {
    showToast('Failed to delete analysis record.', 'error');
  }
}
