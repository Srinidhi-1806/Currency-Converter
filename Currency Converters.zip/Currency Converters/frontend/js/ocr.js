/**
 * OCR Engine & Data Verification Module
 */

async function triggerOCRProcessing(file) {
  const previewWrapper = document.getElementById('imagePreviewContainer');
  if (previewWrapper) {
    previewWrapper.classList.add('scanning');
  }

  showToast('Extracting product details and price with OCR...', 'info');

  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await fetch(`${API_BASE}/ocr/analyze`, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error(`OCR service returned status ${response.status}`);
    }

    const data = await response.json();
    populateDetectedData(data);

    if (data.is_low_confidence) {
      showToast('OCR confidence is low. Please verify and correct the detected values.', 'warning', 6000);
    } else {
      showToast(`Detected ${getCurrencySymbol(data.currency)}${data.price} (${data.confidence * 100}% confidence)`, 'success');
    }

    // Advance to Step 2
    if (window.goToStep) {
      window.goToStep(2);
    }

  } catch (err) {
    console.error('OCR Extraction error:', err);
    showToast('Could not automatically parse image. Please enter details manually.', 'warning', 5000);
    // Allow manual entry
    populateDetectedData({
      raw_text: 'Manual Input Mode',
      price: '',
      currency: 'USD',
      confidence: 0.1,
      product_name_suggestion: 'New Product',
      category_suggestion: 'Electronics',
      is_low_confidence: true,
      warning_message: 'Please fill in product details and price.'
    });
    if (window.goToStep) window.goToStep(2);
  } finally {
    if (previewWrapper) {
      previewWrapper.classList.remove('scanning');
    }
  }
}

function populateDetectedData(data) {
  if (data.image_url) {
    window.currentUploadedImageUrl = data.image_url;
  }
  const priceInput = document.getElementById('detectedPrice');
  const currencySelect = document.getElementById('detectedCurrency');
  const nameInput = document.getElementById('productName');
  const categorySelect = document.getElementById('productCategory');
  const rawTextDisplay = document.getElementById('ocrRawText');
  const confidenceBar = document.getElementById('ocrConfidenceFill');
  const confidenceVal = document.getElementById('ocrConfidenceVal');
  const warningContainer = document.getElementById('ocrWarningMessage');

  if (priceInput) priceInput.value = data.price !== null && data.price !== undefined ? data.price : '';
  if (currencySelect && data.currency) currencySelect.value = data.currency.toUpperCase();
  if (nameInput && data.product_name_suggestion) nameInput.value = data.product_name_suggestion;
  if (categorySelect && data.category_suggestion) categorySelect.value = data.category_suggestion;

  if (rawTextDisplay) rawTextDisplay.innerText = data.raw_text || 'No text recognized';

  const confPercent = Math.round((data.confidence || 0.5) * 100);
  if (confidenceBar) confidenceBar.style.width = `${confPercent}%`;
  if (confidenceVal) confidenceVal.innerText = `${confPercent}%`;

  if (warningContainer) {
    if (data.is_low_confidence || data.warning_message) {
      warningContainer.style.display = 'block';
      warningContainer.innerText = data.warning_message || 'OCR confidence is low. Please verify the detected price and currency.';
    } else {
      warningContainer.style.display = 'none';
    }
  }
}

window.populateDetectedData = populateDetectedData;
