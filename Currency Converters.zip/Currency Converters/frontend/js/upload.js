/**
 * Upload & Image Handling Module
 */

let selectedFile = null;
let currentImageBase64 = null;

// Preset sample scenarios for rapid testing and demonstrations
const SAMPLE_DEMOS = [
  {
    name: "Sony Wireless Headphones",
    price: 49.99,
    currency: "USD",
    category: "Electronics",
    subcategory: "Audio",
    description: "Noise-cancelling wireless stereo headphones ($49.99 USD)",
    imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&auto=format&fit=crop&q=60"
  },
  {
    name: "Classic Leather Jacket",
    price: 59.99,
    currency: "EUR",
    category: "Fashion",
    subcategory: "Apparel",
    description: "Premium European autumn jacket (€59.99 EUR)",
    imageUrl: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=500&auto=format&fit=crop&q=60"
  },
  {
    name: "Supermarket Weekly Basket",
    price: 2499.00,
    currency: "INR",
    category: "Groceries",
    subcategory: "Pantry",
    description: "Fresh produce, dairy & grocery essentials (₹2,499 INR)",
    imageUrl: "https://images.unsplash.com/photo-1542838132-92c53300491e?w=500&auto=format&fit=crop&q=60"
  },
  {
    name: "Nintendo Switch Game Console",
    price: 34980.00,
    currency: "JPY",
    category: "Entertainment",
    subcategory: "Gaming",
    description: "Handheld portable gaming system (¥34,980 JPY)",
    imageUrl: "https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?w=500&auto=format&fit=crop&q=60"
  }
];

function initUploadZone() {
  const dropzone = document.getElementById('dropzone');
  const fileInput = document.getElementById('productImageInput');
  const previewContainer = document.getElementById('imagePreviewContainer');
  const previewImg = document.getElementById('imagePreview');
  const cameraInput = document.getElementById('cameraCaptureInput');

  if (!dropzone || !fileInput) return;

  // Dropzone click
  dropzone.addEventListener('click', (e) => {
    if (e.target.tagName !== 'BUTTON' && !e.target.closest('button')) {
      fileInput.click();
    }
  });

  // Drag and Drop
  ['dragenter', 'dragover'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.add('dragover');
    });
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.remove('dragover');
    });
  });

  dropzone.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    const files = dt.files;
    if (files.length > 0) {
      handleFileSelected(files[0]);
    }
  });

  fileInput.addEventListener('change', (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileSelected(e.target.files[0]);
    }
  });

  if (cameraInput) {
    cameraInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files.length > 0) {
        handleFileSelected(e.target.files[0]);
      }
    });
  }

  // Populate sample preset cards
  renderSampleCards();
}

function handleFileSelected(file) {
  // Validate file type
  const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
  if (!validTypes.includes(file.type)) {
    showToast('Please upload a valid image (JPG, PNG, WEBP).', 'error');
    return;
  }

  // Validate size (10MB max)
  if (file.size > 10 * 1024 * 1024) {
    showToast('Image file size exceeds 10MB limit.', 'error');
    return;
  }

  selectedFile = file;

  const reader = new FileReader();
  reader.onload = (e) => {
    currentImageBase64 = e.target.result;
    displayImagePreview(e.target.result);
    // Automatically trigger OCR processing
    triggerOCRProcessing(file);
  };
  reader.readAsDataURL(file);
}

function displayImagePreview(src) {
  const dropzone = document.getElementById('dropzone');
  const previewContainer = document.getElementById('imagePreviewContainer');
  const previewImg = document.getElementById('imagePreview');

  if (dropzone && previewContainer && previewImg) {
    previewImg.src = src;
    dropzone.style.display = 'none';
    previewContainer.style.display = 'block';
  }
}

function resetImageUpload() {
  selectedFile = null;
  currentImageBase64 = null;
  const dropzone = document.getElementById('dropzone');
  const previewContainer = document.getElementById('imagePreviewContainer');
  const fileInput = document.getElementById('productImageInput');

  if (dropzone && previewContainer) {
    dropzone.style.display = 'block';
    previewContainer.style.display = 'none';
  }
  if (fileInput) fileInput.value = '';
}

function renderSampleCards() {
  const container = document.getElementById('samplePresetsGrid');
  if (!container) return;

  container.innerHTML = SAMPLE_DEMOS.map((demo, idx) => `
    <div class="sample-image-card" onclick="loadSamplePreset(${idx})">
      <img src="${demo.imageUrl}" class="sample-image-thumb" alt="${demo.name}">
      <div class="sample-image-title">${demo.name}</div>
      <div class="sample-image-price">${getCurrencySymbol(demo.currency)}${demo.price} ${demo.currency}</div>
    </div>
  `).join('');
}

function loadSamplePreset(index) {
  const demo = SAMPLE_DEMOS[index];
  if (!demo) return;

  // Display preset preview
  displayImagePreview(demo.imageUrl);

  // Directly populate OCR / Manual fields
  window.populateDetectedData({
    raw_text: `${demo.name}\n${getCurrencySymbol(demo.currency)}${demo.price} ${demo.currency}\nCategory: ${demo.category}`,
    price: demo.price,
    currency: demo.currency,
    confidence: 0.95,
    product_name_suggestion: demo.name,
    category_suggestion: demo.category,
    is_low_confidence: false,
    image_url: demo.imageUrl
  });

  showToast(`Loaded sample scenario: ${demo.name}`, 'success');
  // Advance to Step 2
  if (window.goToStep) window.goToStep(2);
}
